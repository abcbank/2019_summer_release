/*
 * Test_Encoder.h
 *
 *  Created on: 2016. 6. 26.
 *      Author: ����
 */

#ifndef Test_Encoder_H_
#define	Test_Encoder_H_

#include "Gtm/Tom/Timer/IfxGtm_Tom_Timer.h"

void Encoder_Initialization(void);
extern uint32 get_encoder(void);

#endif /* 0_SRC_0_APPSW_APP_INC_TPIM_H_ */
