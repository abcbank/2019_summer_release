/*
 * Buzzer.h
 *
 *  Created on: 2016. 7. 10.
 *      Author: ����
 */

#ifndef BUZZER_H_
#define BUZZER_H_

void BuzzerForShort(void);
void buzzer_Initialization(void);

#endif /* 0_SRC_0_APPSW_APP_INC_BUZZER_H_ */
