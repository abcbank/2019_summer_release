/*
 * TPIM.h
 *
 *  Created on: 2016. 6. 26.
 *      Author: ����
 */

#ifndef TPIM_H_
#define	TPIM_H_

#include "Gtm/Tom/Timer/IfxGtm_Tom_Timer.h"
void encoder_Initialization(void);
extern void tim0_TIEM_init(void);
extern uint32 get_tim0_cnt(void);

#endif /* 0_SRC_0_APPSW_APP_INC_TPIM_H_ */
