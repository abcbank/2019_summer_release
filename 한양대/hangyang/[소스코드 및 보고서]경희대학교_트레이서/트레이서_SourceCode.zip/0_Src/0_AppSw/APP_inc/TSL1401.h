/*
 * TSL1401.h
 *
 *  Created on: 2016. 6. 25.
 *      Author: ����
 */
#ifndef TSL1401_H_
#define TSL1401_H_

#include "Test_Pwm.h"
#include "Test_ADC.h"

#include "IfxPort_reg.h"
#include "IfxPort.h"
#include "glcd.h"

void get_TSL1401(uint16 cam[128], uint16 cam2[128]);
void GLCD_displayCamView(uint16 cam[128], uint16 Amount);
void getTangentLine(uint16 cam[128], uint16 maxIndex, uint16 tangentPoint[128]);
void getLineData
		(uint16 cam[128], uint16 maxIndex, uint16 tangentPoint[128],
		uint16 LineIndex[64][2], uint16* LineAmount, uint16 skipPixel, uint16 Ratio, uint8* thickness);
#endif
