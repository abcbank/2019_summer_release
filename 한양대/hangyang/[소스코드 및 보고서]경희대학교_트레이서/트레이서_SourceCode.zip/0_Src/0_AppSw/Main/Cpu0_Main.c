/**
 * \file Cpu0_Main.c
 * \brief Main function definition for Cpu core 0 .
 *
 * \copyright Copyright (c) 2012 Infineon Technologies AG. All rights reserved.
 *
 *
 *
 *                                 IMPORTANT NOTICE
 *
 *
 * Infineon Technologies AG (Infineon) is supplying this file for use
 * exclusively with Infineon's microcontroller products. This file can be freely
 * distributed within development tools that are supporting such microcontroller
 * products.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 * OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 * INFINEON SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 */

#include "Tricore/Cpu/Std/Ifx_Types.h"
#include "Tricore/Cpu/Std/IfxCpu_Intrinsics.h"
#include "Tricore/Scu/Std/IfxScuWdt.h"
#include <Stm/Std/IfxStm.h>
#include <Port/Std/IfxPort.h>
#include "Test_Irq.h"
#include "Test_ModuleInit.h"
#include <stdio.h>
#include "glcd.h"
#include "system_tc2x.h"
#include "Test_Pwm.h"
#include "Test_Adc.h"
#include "Test_Can.h"
#include "usr_sprintf.h"
#include "TSL1401.h"
#include "TIEM.h"
#include "Buzzer.h"
#include <stdlib.h>

extern uint16 SpeedW;
extern boolean StopGo;
uint16 Start_Main = 1;

extern void TransmissionText(uint16 transdata[]);
void PID(float* SPEED, uint16 SpeedW);
void MiddleDetection(uint16 LineIndex[64][2], uint16 LineAmount
		, int* middle_, int* left_, int* right_, uint16 MaxSize, uint8* lastdirection, uint8* thickness);
extern void ChangeLine();
void changeMiddle(uint16 TSL1401CAMSize_AfterAverageFilter, int* secondmiddle);
void LastDirection(uint8* lastdirection);
void checkThickness(uint16 LineIndex[64][2], uint16 LineAmount, uint8* thickness);

int middle = 64;
int leftline = 0;
int rightline = 127;
int changemiddle = 40;
uint8 PSDmeanStart = 0;
uint8 controlCount01 = 100;
uint8 controlCount02 = 70;
uint8 PSDsign = 0;

int slowchange01 = 10;
int slowchange02 = 100;

uint8 LASTDIRECTION = 1; //
uint8 THICKNESS = 0;



void core0_main (void)
{
    __enable ();

    /*
     * !!WATCHDOG0 AND SAFETY WATCHDOG ARE DISABLED HERE!!
     * Enable the watchdog in the demo if it is required and also service the watchdog periodically
     * */
    IfxScuWdt_disableCpuWatchdog (IfxScuWdt_getCpuWatchdogPassword ());
    IfxScuWdt_disableSafetyWatchdog (IfxScuWdt_getSafetyWatchdogPassword ());

    uint16 cam[128];
    uint16 cam2[128];
    uint16 i;
    uint16 changespeed = 65;
    uint16 runspeed = 1;
    uint8 PSDcount = 0;
    Test_ModuleInit();
    servoTimer_initTimer();
    GLCD_init();
    GLCD_clear(COLOR_WHITE);
    encoder_Initialization();
    float SPEED;
    int secondmiddle = 0;
    const uint16 TSL1401CAMSize = 127;
    uint16 LineIndex[64][2] = {0};
    uint16 LineAmount = 0;
    uint16 mean10PSD = 100;
    buzzer_Initialization();
    uint16 tangentPoint[128] = {0};

    while (1)
    {

    	if(Start_Main)
    	{
    		Start_Main = 0;
    		P13_OUT.B.P0 = ~P13_OUT.B.P0;





    		//--- ī�޶� ������ ���� �� ���� ���� ����---
			get_TSL1401(cam,cam2);										// ī�޶� �� ����
			getTangentLine(cam, TSL1401CAMSize-1, tangentPoint);		// ī�޶� ���� �м��ؼ� ������� ������ �� �ִ� ������ ����
			getLineData(cam, TSL1401CAMSize-1, tangentPoint, LineIndex, &LineAmount, 5, 68, &THICKNESS);	// �� ����
			LastDirection(&LASTDIRECTION);								// ���� ȸ�� �� ����� ������ ��ġ�� �Բ� ��ȯ
			//checkThickness(LineIndex, LineAmount, &THICKNESS);			// �ֱٿ� ���� ���� �β��� ���� �־����� üũ
			MiddleDetection(LineIndex, LineAmount, &middle, &leftline, &rightline, TSL1401CAMSize-11, &LASTDIRECTION, &THICKNESS);
																		// left, middle, right �� ���� ��ġ�� �����ϰ� ���
			changeMiddle(TSL1401CAMSize, &secondmiddle);				// �ڵ����� �߽����� ������ �ϴ� �� ��ȯ
			servo_DutyUpdate((63-secondmiddle)*abs(63-secondmiddle)/100 + 2.2*(63 -secondmiddle));	// ���� ���� ����
			//--- ī�޶� ������ ���� �� ���� ���� ����---





			cam[127] = (uint16)get_tim0_cnt()/3;
			PID(&SPEED, SpeedW);

			if(P14_IN.B.P4)
			{
				GLCD_clear(COLOR_WHITE);
				for(i = 0;i<LineAmount;i++)
					GLCD_putline((LineIndex[i][0] + LineIndex[i][1])/2, 128);
				TransmissionText(cam);
				GLCD_displayInt(210,25,middle);
				GLCD_displayInt(180,25,leftline);
				GLCD_displayInt(150,25,rightline);
				GLCD_displayInt(170, 100, (int)PSD01());
				GLCD_displayInt(170, 200, (int)PSD02());
				GLCD_displayInt(230, 100, (int)getEmitedDiod01());
				GLCD_displayInt(230, 200, (int)getEmitedDiod02());
				GLCD_displayInt(200, 200, (int)SPEED);
				GLCD_displayInt(200, 100, (int)get_tim0_cnt());
				GLCD_displayCamView(cam, TSL1401CAMSize-11);
				GLCD_displayCamView(tangentPoint, TSL1401CAMSize-11);
			}

			if(SPEED > 2000)
				SPEED = 2000;
			if(P14_IN.B.P4 || !StopGo)
				SPEED = 0;
			P13_OUT.B.P4 = 1;

			Pwm_MotorDutyAndDirectionControl((uint16)SPEED,1);

    	}
    	P13_OUT.B.P4 = 1;

		if(controlCount01==100){
			Test_VadcAutoScan(IfxVadc_GroupId_0);
			Test_VadcAutoScan(IfxVadc_GroupId_1);
			if(getEmitedDiod02()<1000 && getEmitedDiod01()<1000
				&& getEmitedDiod03()<1000 &&getEmitedDiod04()<1000 &&!P14_IN.B.P4) // ��ȸ�忡���� 1000
			{
				if(SpeedW == changespeed)
				{
					PSDsign = 2;
					SpeedW = runspeed;
					if(changemiddle < 0)
						ChangeLine();
				}
				else{
					runspeed = SpeedW;
					SpeedW = changespeed;
					PSDsign = 1;
				}
				controlCount01 = 0;


			}
		}
		if(controlCount02 == 70){
			Test_VadcAutoScan(IfxVadc_GroupId_1);
			if((/*PSD01() > 500 || */PSD01() > 600) && !P14_IN.B.P4)
			{
				PSDcount++;
				if(PSDcount == 5){
					if(PSD01() > 800){//+ mean10PSD){
						if(PSDsign == 1){
							PSDcount = 0;
							controlCount02 = 0;
							ChangeLine();
						}
						if(PSDsign == 2)
						{
							PSDcount = 0;
							controlCount02 = 0;
							StopGo = 0;
						}
						BuzzerForShort();
					}
					else
						PSDcount--;
				}
			}
			else{
				if(PSDmeanStart)
					mean10PSD = PSD01()/10 + mean10PSD*9/10;
				PSDmeanStart = 0;
				PSDcount = 0;
			}

		}


    }

}

void SecondTimer_Initialization(void)
{
    Ifx_STM             *stm = &MODULE_STM0;
    IfxStm_CompareConfig stmCompareConfig;

    IfxStm_enableOcdsSuspend(stm);
    IfxStm_initCompareConfig(&stmCompareConfig);
	stmCompareConfig.triggerPriority = ISR_PRIORITY_STM;
	stmCompareConfig.ticks = 2000000;
	stmCompareConfig.typeOfService = IfxSrc_Tos_cpu0;
    IfxStm_initCompare(stm, &stmCompareConfig);

}
IFX_INTERRUPT (SecondTimer_Isr, 0, ISR_PRIORITY_STM);
void SecondTimer_Isr(void)
{
    Ifx_STM *stm = &MODULE_STM0;

    if(controlCount01 < 100)
    {
    	controlCount01++;
    	THICKNESS = 0;
    }

    if(controlCount02 < 70)
    {
        controlCount02++;
        THICKNESS = 0;
    }

    if(slowchange01 < 10)
    	slowchange01++;

    if(slowchange02 < 100)
    	slowchange02++;
    P13_OUT.B.P3 = ~P13_OUT.B.P3;
    P13_OUT.B.P1 = ~P13_OUT.B.P3;
    Start_Main = 1;
    PSDmeanStart = 1;
    IfxStm_updateCompare(stm, IfxStm_Comparator_0, IfxStm_getLower(stm) + 2000000);

    __enable();

}


void PID(float* SPEED, uint16 Speed) // ���ڴ��� �̿��� P����
{
	int P;
	P = Speed - get_tim0_cnt();	//get_tim0_cnt() return speed

	if(P14_IN.B.P4)
		GLCD_displayInt(230, 100, P);
	if(P > 0)
	{
		if(slowchange02 < 100)
			*SPEED = ((float)*SPEED + (float)(P>>4));
		else
			*SPEED = ((float)*SPEED + (float)(P>>2));

	}
	else
	{
		if(slowchange01 < 10)
			*SPEED = ((float)*SPEED + (float)(P));
		else
			*SPEED = ((float)*SPEED + (float)(P>>1));
	}

}




// ---- right, middle, right �� �������� �� ���� ��ġ�� ���� �� ����ϴ� �Լ� ���� ----
uint16 DETECTIONCounter = 0;
uint16 CompareIndex = 0;
uint8 DetectionFlag = 4;
const uint16 DistanceLimit = 75;

uint16 AfterThickBarCam[32] = {0};
uint16 AfterThickCounter = 0;
void MiddleDetection(uint16 LineIndex[64][2], uint16 LineAmount
		, int* middle_, int* left_, int* right_, uint16 MaxSize, uint8* lastdirection, uint8* thickness)
{

	int CompareValue = MaxSize;
	uint16 CompareIndex = 0;
	int CompareValueR = MaxSize;
	uint16 CompareIndexR = MaxSize - 1;
	int CompareValueL = MaxSize;
	uint16 CompareIndexL = 0;

	unsigned int index = 0;

	if(LineAmount>5)					// ���� 5�� �ʰ��� ���� �� ��� ���� ������ ���
	{
		return;
	}
	else if(LineAmount == 0)
	{
		DETECTIONCounter++;
		if(DETECTIONCounter > 30)		// ���� �ð� ���� �������� ���� ��� ����������ġ�� �ʱ�ȭ
		{
			*middle_ = 0;
			*right_ = MaxSize - 1;
			*left_ = 0;
			DetectionFlag = 4;
			DETECTIONCounter = 0;
		}
	}
	else
	{
		DETECTIONCounter = 0;

		if(*thickness == 1)				// �β��� ���� ����� ���� �ִ� ��� �ٽ� ���ο� ���� ���� �ȴٸ�, ���ο� ���� ��ġ ����
		{

			int CompareValueTemp = MaxSize;
			uint16 CompareIndexTemp = MaxSize;
			unsigned int indexTemp = 0;
			if(lastdirection == 1)
			{
				while(indexTemp < LineAmount)
				{
					if(LineIndex[indexTemp][1]-LineIndex[indexTemp][0] < 40)
					{
						if(CompareValueTemp > abs(MaxSize/2 - 30 - (LineIndex[indexTemp][0] + LineIndex[indexTemp][1])/2))
						{
							CompareValueTemp = abs(MaxSize/2 - 30 - (LineIndex[indexTemp][0] + LineIndex[indexTemp][1])/2);
							CompareIndexTemp = (LineIndex[indexTemp][0] + LineIndex[indexTemp][1])/2;
						}
					}
					indexTemp++;
				}
				if(CompareIndexTemp < MaxSize - 21 && CompareIndexTemp > 1)
				{
					*middle_ = CompareIndexTemp;
					*right_ = MaxSize-1;
					*left_ = 0;
					AfterThickCounter++;
				}
				else
				{
					return;
				}
			}
			else if(lastdirection == 2)
			{
				while(indexTemp < LineAmount)
				{
					if(LineIndex[indexTemp][1]-LineIndex[indexTemp][0] < 40)
					{
						if(CompareValueTemp > abs(MaxSize/2 - 30 - (LineIndex[indexTemp][0] + LineIndex[indexTemp][1])/2))
						{
							CompareValueTemp = abs(MaxSize/2 - 30 - (LineIndex[indexTemp][0] + LineIndex[indexTemp][1])/2);
							CompareIndexTemp = (LineIndex[indexTemp][0] + LineIndex[indexTemp][1])/2;
						}
					}
					indexTemp++;
				}
				if(CompareIndexTemp < MaxSize - 21 && CompareIndexTemp > 1)
				{
					*middle_ = MaxSize-1;
					*right_ = MaxSize-1;
					*left_ = CompareIndexTemp;
					AfterThickCounter++;
				}
				else
				{
					return;
				}
			}
			else if(lastdirection == 3)
			{
				while(indexTemp < LineAmount)
				{
					if(LineIndex[indexTemp][1]-LineIndex[indexTemp][0] < 40)
					{
						if(CompareValueTemp > abs(MaxSize/2 + 30 - (LineIndex[indexTemp][0] + LineIndex[indexTemp][1])/2))
						{
							CompareValueTemp = abs(MaxSize/2 + 30 - (LineIndex[indexTemp][0] + LineIndex[indexTemp][1])/2);
							CompareIndexTemp = (LineIndex[indexTemp][0] + LineIndex[indexTemp][1])/2;
						}
					}
					indexTemp++;
				}
				if(CompareIndexTemp > 20 && CompareIndexTemp < MaxSize - 2)
				{
					*middle_ = 0;
					*right_ = CompareIndexTemp;
					*left_ = 0;
					AfterThickCounter++;
				}
				else
				{
					return;
				}
			}
			else if(lastdirection == 4)
			{
				while(indexTemp < LineAmount)
				{
					if(LineIndex[indexTemp][1]-LineIndex[indexTemp][0] < 40)
					{
						if(CompareValueTemp > abs(MaxSize/2 + 30 - (LineIndex[indexTemp][0] + LineIndex[indexTemp][1])/2))
						{
							CompareValueTemp = abs(MaxSize/2 + 30 - (LineIndex[indexTemp][0] + LineIndex[indexTemp][1])/2);
							CompareIndexTemp = (LineIndex[indexTemp][0] + LineIndex[indexTemp][1])/2;
						}
					}
					indexTemp++;
				}
				if(CompareIndexTemp > 20 && CompareIndexTemp < MaxSize - 2)
				{
					*middle_ = CompareIndexTemp;
					*right_ = MaxSize-1;
					*left_ = 0;
					AfterThickCounter++;
				}
				else
				{
					return;
				}
			}

			uint16 THICKCounterMax = 0;
			if(PSDsign == 0 || PSDsign == 2)
			{
				THICKCounterMax = 3;
			}
			else if(PSDsign == 1)
			{
				THICKCounterMax = 9;
			}

			AfterThickBarCam[AfterThickCounter-1] = CompareIndexTemp;
			if(AfterThickCounter >= THICKCounterMax)
			{
				//BuzzerForShort();
				uint16 tempBarcam = 0;
				unsigned int TempTempIndex = 0;
				while(TempTempIndex < THICKCounterMax)
				{
					tempBarcam += AfterThickBarCam[TempTempIndex];
					TempTempIndex++;
				}
				tempBarcam /= THICKCounterMax;
				*thickness = 0;
				AfterThickCounter = 0;
				if(lastdirection == 1)
				{
					*middle_ = tempBarcam;
					*right_ = MaxSize-1;
					*left_ = 0;
					return;
				}
				else if(lastdirection == 2)
				{
					*middle_ = MaxSize-1;
					*right_ = MaxSize-1;
					*left_ = tempBarcam;
					return;
				}
				else if(lastdirection == 3)
				{
					*middle_ = 0;
					*right_ = tempBarcam;
					*left_ = 0;
					return;
				}
				else if(lastdirection == 4)
				{
					*middle_ = tempBarcam;
					*right_ = MaxSize-1;
					*left_ = 0;
					return;
				}
			}
			return;
		}


		while(index < LineAmount)				// ���� left, middle, right ���� ���ؼ� ���� ������ �ִ� �� ��ġ ����
		{
			if(LineIndex[index][1]-LineIndex[index][0] < 40)
			{
				if(CompareValue > abs(*middle_ - (LineIndex[index][0] + LineIndex[index][1])/2))
				{
					CompareValue = abs(*middle_ - (LineIndex[index][0] + LineIndex[index][1])/2);
					CompareIndex = (LineIndex[index][0] + LineIndex[index][1])/2;
				}
				if(CompareValueR > abs(*right_ - (LineIndex[index][0] + LineIndex[index][1])/2))
				{
					CompareValueR = abs(*right_ - (LineIndex[index][0] + LineIndex[index][1])/2);
					CompareIndexR = (LineIndex[index][0] + LineIndex[index][1])/2;
				}
				if(CompareValueL > abs(*left_ - (LineIndex[index][0] + LineIndex[index][1])/2))
				{
					CompareValueL = abs(*left_ - (LineIndex[index][0] + LineIndex[index][1])/2);
					CompareIndexL = (LineIndex[index][0] + LineIndex[index][1])/2;
				}
			}
			index++;
		}

		if(DetectionFlag == 0)
		{
			if(CompareValueL < 20)
			{
				DetectionFlag = 1;
				CompareIndex = MaxSize - 1;
				CompareIndexR = MaxSize - 1;
			}
			else
			{
				CompareIndexL = MaxSize - 1;
				CompareIndex = MaxSize - 1;
				CompareIndexR = MaxSize - 1;
			}
		}
		else if(DetectionFlag == 1)
		{
			if(CompareValueL < 20 && CompareValue < 20)
			{
				if(*middle_ - *left_ > DistanceLimit)
				{
					DetectionFlag = 2;
					CompareIndexR = MaxSize - 1;
				}
				else
				{
					CompareIndex = MaxSize - 1;
					CompareIndexR = MaxSize - 1;
				}

			}
			else if(CompareValueL < 20)
			{
				CompareIndex = MaxSize - 1;
				CompareIndexR = MaxSize - 1;
			}
			else if(CompareValue < 20)
			{
				if(*left_ < 21)
				{
					DetectionFlag = 3;
					CompareIndexL = 0;
					CompareIndexR = MaxSize - 1;
				}
				else
				{
					CompareIndexL = *left_;
					CompareIndex = *middle_;
					CompareIndexR = *right_;
				}
			}
			else
			{
				if(*left_ > MaxSize/2)
				{
					DetectionFlag = 0;
					CompareIndexL = MaxSize - 1;
					CompareIndex = MaxSize - 1;
					CompareIndexR = MaxSize - 1;
				}
				else
				{
					DetectionFlag = 2;
					CompareIndexL = 0;
					CompareIndex = MaxSize - 1;
					CompareIndexR = MaxSize - 1;
				}
			}
		}
		else if(DetectionFlag == 2)
		{
			if(CompareValueL < 20 && CompareValue < 20)
			{
				if(*middle_ - *left_ > DistanceLimit)
				{
					CompareIndexR = MaxSize - 1;
				}
				else
				{
					DetectionFlag = 3;
					CompareIndexL = 0;
					CompareIndexR = MaxSize - 1;
				}
			}
			else if(CompareValueL < 20)
			{
				DetectionFlag = 1;
				CompareIndex = MaxSize - 1;
				CompareIndexR = MaxSize - 1;
			}
			else if(CompareValue < 20)
			{
				DetectionFlag = 3;
				CompareIndexL = 0;
				CompareIndexR = MaxSize - 1;
			}
			else
			{
				CompareIndexL = 0;
				CompareIndex = MaxSize - 1;
				CompareIndexR = MaxSize - 1;
			}
		}
		else if(DetectionFlag == 3)
		{
			if(CompareValueL < 20 && CompareValue < 20 && CompareValueR < 20)
			{
				if(*middle_ - *left_ <= DistanceLimit)
				{
					CompareIndexL = 0;
				}
				if(*right_ - *middle_ <= DistanceLimit)
				{
					CompareIndexR = MaxSize - 1;
				}
				if(CompareIndexL != 0)
				{
					DetectionFlag = 2;
				}
				if(CompareIndexR != MaxSize - 1)
				{
					DetectionFlag = 4;
				}
			}
			else if(CompareValueL < 20 && CompareValue < 20 && CompareValueR >= 20)
			{
				if(*middle_ - *left_ > DistanceLimit)
				{
					DetectionFlag = 2;
					CompareIndexR = MaxSize - 1;
				}
				else
				{
					CompareIndexL = 0;
					CompareIndexR = MaxSize - 1;
				}
			}
			else if(CompareValueL >= 20 && CompareValue < 20 && CompareValueR < 20)
			{
				if(*right_ - *middle_ > DistanceLimit)
				{
					DetectionFlag = 4;
					CompareIndexL = 0;
				}
				else
				{
					CompareIndexL = 0;
					CompareIndexR = MaxSize - 1;
				}
			}
			else if(CompareValueL >= 20 && CompareValue < 20 && CompareValueR >= 20)
			{
				CompareIndexL = 0;
				CompareIndexR = MaxSize - 1;
			}
			else if(CompareValue >= 20)
			{
				CompareIndexL = 0;
				CompareIndex = *middle_;
				CompareIndexR = MaxSize - 1;
			}
			else
			{
				CompareIndexL = *left_;
				CompareIndex = *middle_;
				CompareIndexR = *right_;
			}
		}
		else if(DetectionFlag == 4)
		{
			if(CompareValue < 20 && CompareValueR < 20)
			{
				if(*right_ - *middle_ > DistanceLimit)
				{
					CompareIndexL = 0;
				}
				else
				{
					DetectionFlag = 3;
					CompareValueL = 0;
					CompareValueR = MaxSize - 1;
				}
			}
			else if(CompareValue < 20)
			{
				DetectionFlag = 3;
				CompareIndexL = 0;
				CompareIndexR = MaxSize - 1;
			}
			else if(CompareValueR < 20)
			{
				DetectionFlag = 5;
				CompareIndexL = 0;
				CompareIndex = 0;
			}
			else
			{
				CompareIndexL = 0;
				CompareIndex = 0;
				CompareIndexR = MaxSize - 1;
			}
		}
		else if(DetectionFlag == 5)
		{
			if(CompareValue < 20 && CompareValueR < 20)
			{
				if(*right_ - *middle_ > DistanceLimit)
				{
					DetectionFlag = 4;
					CompareIndexL = 0;
				}
				else
				{
					CompareIndexL = 0;
					CompareIndex = 0;
				}
			}
			else if(CompareValue < 20)
			{
				if(*right_ > MaxSize-1-21)
				{
					DetectionFlag = 3;
					CompareIndexR = MaxSize - 1;
					CompareIndexL = 0;
				}
				else
				{
					CompareIndexL = *left_;
					CompareIndex = *middle_;
					CompareIndexR = *right_;
				}
			}
			else if(CompareValueR < 20)
			{
				CompareIndexL = 0;
				CompareIndex = 0;
			}
			else
			{
				if(*right_ > MaxSize/2)
				{
					DetectionFlag = 4;
					CompareIndexL = 0;
					CompareIndex = 0;
					CompareIndexR = MaxSize - 1;
				}
				else
				{
					DetectionFlag = 6;
					CompareIndexL = 0;
					CompareIndex = 0;
					CompareIndexR = 0;
				}
			}
		}
		else if(DetectionFlag == 6)
		{
			if(CompareValueR < 20)
			{
				DetectionFlag = 5;
				CompareIndexL = 0;
				CompareIndex = 0;
			}
			else
			{
				CompareIndexL = 0;
				CompareIndex = 0;
				CompareIndexR = 0;
			}
		}

		*middle_ = CompareIndex;
		*right_ = CompareIndexR;
		*left_ = CompareIndexL;
	}
}
// ---- right, middle, right �� �������� �� ���� ��ġ�� ���� �� ����ϴ� �Լ� ���� ----




void ChangeLine()
// Post : ���� ����
{
	changemiddle = -changemiddle;
}
int lineInterval = 70;
void changeMiddle(uint16 TSL1401CAMSize, int* secondmiddle)
// Post : left, middle, right�� ��ġ�� �������� �ϸ�, ���� ķ�� ��Ȳ�� �����Ͽ� �ڵ����� �޷����� �߾� �� ��ġ ��ȯ
{
	float middleRatio = 1.3;
	float EntryRatio = 1.0 + middleRatio;
	if(changemiddle > 0)
	{
		if(middle > 0 && rightline < TSL1401CAMSize-11 && rightline - middle > 70)
		{
			*secondmiddle = (middleRatio*(float)middle + (float)rightline)/EntryRatio;
			lineInterval += (rightline - middle);
			lineInterval /= 2;
		}
		else if(middle > 0)
		{
			*secondmiddle = (middleRatio*(float)middle + ((float)middle + (float)lineInterval))/EntryRatio;
		}
		else if(rightline < TSL1401CAMSize-11)
		{
			*secondmiddle = ((float)rightline + middleRatio*((float)rightline - (float)lineInterval))/EntryRatio;
		}
		else
		{
			*secondmiddle = (middleRatio*(float)middle + (float)rightline)/EntryRatio;
		}
	}
	else
	{
		if(middle < TSL1401CAMSize-11 && leftline > 0 && middle - leftline > 70)
		{
			*secondmiddle = (middleRatio*(float)middle + (float)leftline)/EntryRatio;
			lineInterval += (middle - leftline);
			lineInterval /= 2;
		}
		else if(leftline > 0)
		{
			*secondmiddle = (middleRatio*((float)leftline + (float)lineInterval) + (float)leftline)/EntryRatio;
		}
		else if(middle < TSL1401CAMSize-11)
		{
			*secondmiddle =  (middleRatio*(float)middle + ((float)middle - lineInterval))/EntryRatio;
		}
		else
		{
			*secondmiddle = (middleRatio*(float)middle + (float)leftline)/EntryRatio;
		}
	}
}


void LastDirection(uint8* lastdirection)
// Post : ���� ȸ�� ���� �� ������ ��ġ�� ��ȯ
{
	if(changemiddle > 0 && DetectionFlag < 4)
	{
		*lastdirection = 1;
		// ������������ ��ȸ��
	}
	else if(changemiddle < 0 && DetectionFlag < 2)
	{
		*lastdirection = 2;
		// ������������ ��ȸ��
	}
	else if(changemiddle > 0 && DetectionFlag > 4)
	{
		*lastdirection = 3;
		// ������������ ��ȸ��
	}
	else if(changemiddle > 0 && DetectionFlag > 2)
	{
		*lastdirection = 4;
		// ������������ ��ȸ��
	}
}


void checkThickness(uint16 LineIndex[64][2], uint16 LineAmount, uint8* thickness)
// Post : �ֱٿ� �β��� ���� �������� �ִ����� ��ȯ
{
	unsigned int index = 0;
	while(index < LineAmount)
	{
		if(LineIndex[index][1] - LineIndex[index][0] > 22)
		{
			*thickness = 1;
		}
		index++;
	}
}
