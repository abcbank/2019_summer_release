/******************************************************************************
**                                                                           **
** Copyright (C) Infineon Technologies (2013)                                **
**                                                                           **
** All rights reserved.                                                      **
**                                                                           **
** This document contains proprietary information belonging to Infineon      **
** Technologies. Passing on and copying of this document, and communication  **
** of its contents is not permitted without prior written authorization.     **
**                                                                           **
*******************************************************************************
**                                                                           **
**  $FILENAME   : Test_Uart.c $                                              **
**                                                                           **
**  $CC VERSION : \main\16 $                                                 **
**                                                                           **
**  $DATE       : 2013-07-03 $                                               **
**                                                                           **
**  AUTHOR      : DL-AUTOSAR-Engineering                                     **
**                                                                           **
**  VENDOR      : Infineon Technologies                                      **
**                                                                           **
**  DESCRIPTION : This file contains                                         **
**                - sample Demo Application for UART module                  **
**                                                                           **
**  MAY BE CHANGED BY USER [yes/no]: yes                                     **
**                                                                           **
******************************************************************************/
/*******************************************************************************
**                      Includes                                              **
*******************************************************************************/
#include <stdio.h>
#include <Ifx_Types.h>
#include <Asclin/Asc/IfxAsclin_Asc.h>
#include "Test_Irq.h"
#include "glcd.h"

#define ASC_TX_BUFFER_SIZE 64
#define ASC_RX_BUFFER_SIZE 64
#define UART_TEST_DATA_SIZE		10U
//#define UART_TEST_DATA_SIZE_FOR_TX   30U

char outputChar;


//****************************************************************************
// @Typedefs
//****************************************************************************
typedef struct
{
    uint8 tx[ASC_TX_BUFFER_SIZE + sizeof(Ifx_Fifo) + 8];
    uint8 rx[ASC_RX_BUFFER_SIZE + sizeof(Ifx_Fifo) + 8];
} AppAscBuffer;

/** \brief Asc information */
typedef struct
{
    AppAscBuffer ascBuffer;                     /**< \brief ASC interface buffer */
    struct
    {
        IfxAsclin_Asc asc0;                     /**< \brief ASC interface */
        IfxAsclin_Asc asc1;                     /**< \brief ASC interface */
    }         drivers;

    uint8 Uart_TxData[UART_TEST_DATA_SIZE];
    uint8 Uart_RxData[UART_TEST_DATA_SIZE];

	uint16	TxComplete		:16;
	uint16	RxComplete		:16;
	uint16	ErComplete		:16;

    Ifx_SizeT count;
} App_AsclinAsc;

/*******************************************************************************
**                      Private Variable Declarations                         **
*******************************************************************************/

App_AsclinAsc AsclinAsc; /**< \brief Demo information */

/*******************************************************************************
**                      Global Function Definitions                           **
*******************************************************************************/
void Uart_Initialization(void);
void Uart_Test(void);


//******************************************************************************
// @Function	 	void Uart_Initialization(void)
// @Description   	UART initialization for test with StarterKit
// @Returnvalue		None
// @Parameters    	None
//******************************************************************************
void Uart_Initialization(void)
{
	static uint8 i;

	/* disable interrupts */
    boolean              interruptState = IfxCpu_disableInterrupts();
    /* create module config */
    IfxAsclin_Asc_Config Uart_AscLin0;
    IfxAsclin_Asc_initModuleConfig(&Uart_AscLin0, &MODULE_ASCLIN0);

    /* set the desired baudrate */
    Uart_AscLin0.baudrate.prescaler    = 1;
    Uart_AscLin0.baudrate.baudrate     = 115200; /* FDR values will be calculated in initModule */
    Uart_AscLin0.baudrate.oversampling = IfxAsclin_OversamplingFactor_4;
    //Uart_AscLin0.clockSource			= 2;

    /* ISR priorities and interrupt target */
    Uart_AscLin0.interrupt.txPriority    = ISR_PRIORITY_ASCLIN0_TX;
    Uart_AscLin0.interrupt.rxPriority    = ISR_PRIORITY_ASCLIN0_RX;
    Uart_AscLin0.interrupt.erPriority    = ISR_PRIORITY_ASCLIN0_ER;
    Uart_AscLin0.interrupt.typeOfService = IfxSrc_Tos_cpu0;

    /* FIFO configuration */
    Uart_AscLin0.txBuffer     = AsclinAsc.ascBuffer.tx;
    Uart_AscLin0.txBufferSize = ASC_TX_BUFFER_SIZE;

    Uart_AscLin0.rxBuffer     = AsclinAsc.ascBuffer.rx;
    Uart_AscLin0.rxBufferSize = ASC_RX_BUFFER_SIZE;
    Uart_AscLin0.dataBufferMode = 0;

	const IfxAsclin_Asc_Pins pins = {
        NULL,                     IfxPort_InputMode_pullUp,        /* CTS pin not used */
        &IfxAsclin0_RXB_P15_3_IN, IfxPort_InputMode_pullUp,        /* Rx pin */
        NULL,                     IfxPort_OutputMode_pushPull,     /* RTS pin not used */
        &IfxAsclin0_TX_P15_2_OUT, IfxPort_OutputMode_pushPull,     /* Tx pin */
        IfxPort_PadDriver_cmosAutomotiveSpeed1
    };
    Uart_AscLin0.pins = &pins;

	for(i=0; i<UART_TEST_DATA_SIZE; i++)
	{
		AsclinAsc.Uart_TxData[i] = i;
	}

    /* initialize module */
    IfxAsclin_Asc_initModule(&AsclinAsc.drivers.asc0, &Uart_AscLin0);

    /* enable interrupts again */
    IfxCpu_restoreInterrupts(interruptState);



} /* End of Uart_Initialization */


//******************************************************************************
// @Function	 	void Uart_Test(void)
// @Description   	UART communication test
// @Returnvalue		None
// @Parameters    	None
//******************************************************************************
void Uart_Test(void)
{ 
	static	uint8	i=0;

	    /* Transmit data */
	    AsclinAsc.count = UART_TEST_DATA_SIZE;
	    IfxAsclin_Asc_write(&AsclinAsc.drivers.asc0,AsclinAsc.Uart_TxData, &AsclinAsc.count, TIME_INFINITE);

	    /* Receive data */
	    IfxAsclin_Asc_read(&AsclinAsc.drivers.asc0, AsclinAsc.Uart_RxData, &AsclinAsc.count, 0xFF);



//		for(i=0; i<UART_TEST_DATA_SIZE; i++)
//		{
//			AsclinAsc.Uart_TxData[i] = AsclinAsc.Uart_TxData[i]+1;
//		}

}	/* End of Kline_Test */


unsigned int* getRXdataAddress(void)
{
	//return &AsclinAsc.drivers.asc0.asclin->RXDATA.U;
	return &AsclinAsc.drivers.asc0.asclin->RXDATAD.U;
}



unsigned int* getRXaddress(void)
{
	//return &AsclinAsc.drivers.asc0.asclin->RXDATA.U;
	//return AsclinAsc.drivers.asc0.rx->startIndex;
	return &AsclinAsc.drivers.asc0.rx->buffer;

}

Ifx_SizeT getRXsize(void)
{
	return &AsclinAsc.drivers.asc0.rx->endIndex;
}

char getRXChar(void)
{
	return ((char*)AsclinAsc.drivers.asc0.rx->buffer)[AsclinAsc.drivers.asc0.rx->endIndex];
}

void RXBufferClear(void)
{
	Ifx_Fifo_flush(AsclinAsc.drivers.asc0.rx->buffer, TIME_INFINITE);
}

uint8* RXBufferASC(void)
{
	return AsclinAsc.ascBuffer.rx;
}

uint8* RXTESTDATA(void)
{
	return AsclinAsc.Uart_RxData;
}




void TransmissionText(uint16 transdata[])
{
	unsigned int index = -1;
	unsigned int whileIndex = 0;

	while(whileIndex < 13)
	{
		TransmissionText_Sub(transdata, &index);
		whileIndex++;

		AsclinAsc.count = UART_TEST_DATA_SIZE;
		IfxAsclin_Asc_write(&AsclinAsc.drivers.asc0,AsclinAsc.Uart_TxData, &AsclinAsc.count, TIME_INFINITE);
	}

}

void TransmissionText_Sub(uint16 Subtransdata[], unsigned int* index)
{
	int TxDataIndex = 0;
	while(TxDataIndex < UART_TEST_DATA_SIZE)
	{
		if(*index == -1 )
		{
			AsclinAsc.Uart_TxData[TxDataIndex] = '#';
			TxDataIndex++;
			*index = (*index)+1;
		}
		else if(*index == 128)
		{
			AsclinAsc.Uart_TxData[UART_TEST_DATA_SIZE - 1] = '!';
			//AsclinAsc.Uart_TxData[UART_TEST_DATA_SIZE - 1] = '\n';
			//AsclinAsc.Uart_TxData[256%UART_TEST_DATA_SIZE + 3] = '\n';
			return;
		}

		else
		{
			AsclinAsc.Uart_TxData[TxDataIndex] = Subtransdata[(*index)] + 128;
			*index = (*index)+1;
			TxDataIndex++;
		}
		/*
		else if((*index)%2 == 0)
		{
			AsclinAsc.Uart_TxData[TxDataIndex] = ',';
			*index = (*index)+1;
			TxDataIndex++;
		}
		*/
		/*
		if(*index == -1 || *index == -2 || *index == -3 || *index == -4)
		{
			AsclinAsc.Uart_TxData[TxDataIndex] = '#';
			TxDataIndex++;
			*index = (*index)+1;
		}
		else if(*index == 384)
		{
			AsclinAsc.Uart_TxData[UART_TEST_DATA_SIZE - 2] = ',';
			AsclinAsc.Uart_TxData[UART_TEST_DATA_SIZE - 1] = '\n';
			//AsclinAsc.Uart_TxData[256%UART_TEST_DATA_SIZE + 3] = '\n';
			return;
		}
		else if((*index)%3 == 2)
		{
			AsclinAsc.Uart_TxData[TxDataIndex] = (Subtransdata[(*index)/3]>>8);
			*index = (*index)+1;
			TxDataIndex++;
		}
		else if((*index)%3 == 1)
		{
			AsclinAsc.Uart_TxData[TxDataIndex] = Subtransdata[(*index)/3] + 128;
			*index = (*index)+1;
			TxDataIndex++;
		}
		else if((*index)%3 == 0)
		{
			AsclinAsc.Uart_TxData[TxDataIndex] = ',';
			*index = (*index)+1;
			TxDataIndex++;
		}
*/
		/*
		if(Subtransdata[*index] != '\0')
			AsclinAsc.Uart_TxData[TxDataIndex] = Subtransdata[*index];
		else
			AsclinAsc.Uart_TxData[TxDataIndex] = 1;
		*index = (*index)+1;
		TxDataIndex++;
		*/

	}
}


IFX_INTERRUPT(Uart_AscLin0_TxIsr, 0, ISR_PRIORITY_ASCLIN0_TX)
{
    IfxAsclin_Asc_isrTransmit(&AsclinAsc.drivers.asc0);
    AsclinAsc.TxComplete++;
    __enable();
}

/** \} */

/** \name Interrupts for Receive
 * \{ */








// ----------------------------Queue by Hong Hyeon Seok---------------------------
// -------------------------------2016.06.26--------------------------------------
typedef char QueueForTextRX_Type;
int QueueForTextRX_maxQueue = 5;
typedef struct
{
	QueueForTextRX_Type Data[5];	// Data[QueueForTextRX_maxQueue]
	uint8 head;
	uint8 tail;
}QueueForTextRX;

QueueForTextRX QueueForRx;

void QueueForTextRX_Initialize_ForExtern(void)  // extern void QueueForTextRX_Initialize_ForExtern(void); should include
{
	QueueForTextRX_Initialize(&QueueForRx);
}
void QueueForTextRX_Initialize(QueueForTextRX* queue)
{
	queue->tail = QueueForTextRX_maxQueue-1;
	queue->head = QueueForTextRX_maxQueue-1;
	int index = 0;
	while(index < QueueForTextRX_maxQueue)
	{
		queue->Data[index] = '\0';
		index++;
	}
}

boolean QueueForTextRX_IsEmpty(QueueForTextRX* queue)
{
	return (queue->tail == queue->head);
}

boolean QueueForTextRX_IsFull(QueueForTextRX* queue)
{
	return ((queue->head + 1)%QueueForTextRX_maxQueue == queue->tail);
}

void QueueForTextRX_Enqueue(QueueForTextRX* queue, QueueForTextRX_Type input)
{
	/*
	if(QueueForTextRX_IsFull(&queue))
		return;
		*/ // Normal case
	if(QueueForTextRX_IsFull(queue))
	{
		queue->head = (queue->head + 1)%QueueForTextRX_maxQueue;
	}
	queue->tail = (queue->tail + 1)%QueueForTextRX_maxQueue;
	queue->Data[queue->tail] = input;
}

void QueueForTextRX_Dequeue(QueueForTextRX* queue, QueueForTextRX_Type* output)
{
	if(QueueForTextRX_IsEmpty(queue))
		return;
	queue->head = queue->head+1;
	*output = queue->Data[queue->head];
}
uint16 SpeedW=140;
boolean StopGo = 1;
void QueueForTextRX_LED(QueueForTextRX* queue)
{
	if(queue->Data[queue->tail] == '!')
    	if(queue->Data[(queue->tail-1+QueueForTextRX_maxQueue)%QueueForTextRX_maxQueue] == 'R')
    		if(queue->Data[(queue->tail-2+QueueForTextRX_maxQueue)%QueueForTextRX_maxQueue] == 'C')
    			if(queue->Data[(queue->tail-3+QueueForTextRX_maxQueue)%QueueForTextRX_maxQueue] == '#')
    				GLCD_clear(COLOR_RED);
    if(queue->Data[queue->tail] == '!')
    	 if(queue->Data[(queue->tail-1+QueueForTextRX_maxQueue)%QueueForTextRX_maxQueue] == 'B')
    	    if(queue->Data[(queue->tail-2+QueueForTextRX_maxQueue)%QueueForTextRX_maxQueue] == 'C')
    	    	if(queue->Data[(queue->tail-3+QueueForTextRX_maxQueue)%QueueForTextRX_maxQueue] == '#')
    	    		GLCD_clear(COLOR_BLUE);
    if(queue->Data[queue->tail] == '!')
    		 if(queue->Data[(queue->tail-1+QueueForTextRX_maxQueue)%QueueForTextRX_maxQueue] == 'U')
    			if(queue->Data[(queue->tail-2+QueueForTextRX_maxQueue)%QueueForTextRX_maxQueue] == 'S')
    				if(queue->Data[(queue->tail-3+QueueForTextRX_maxQueue)%QueueForTextRX_maxQueue] == '#')//SPEED UP
       						SpeedW+=10;
    if(queue->Data[queue->tail] == '!')
       		 if(queue->Data[(queue->tail-1+QueueForTextRX_maxQueue)%QueueForTextRX_maxQueue] == 'D')
       			if(queue->Data[(queue->tail-2+QueueForTextRX_maxQueue)%QueueForTextRX_maxQueue] == 'S')
       				if(queue->Data[(queue->tail-3+QueueForTextRX_maxQueue)%QueueForTextRX_maxQueue] == '#')//SPEED DOWN
       						SpeedW-=10;
    if(queue->Data[queue->tail] == '!')
          	 if(queue->Data[(queue->tail-1+QueueForTextRX_maxQueue)%QueueForTextRX_maxQueue] == 'Q')
          		if(queue->Data[(queue->tail-2+QueueForTextRX_maxQueue)%QueueForTextRX_maxQueue] == 'S')
          			if(queue->Data[(queue->tail-3+QueueForTextRX_maxQueue)%QueueForTextRX_maxQueue] == '#')//STOP
          				StopGo = !StopGo;
    if(queue->Data[queue->tail] == '!')
              	if(queue->Data[(queue->tail-1+QueueForTextRX_maxQueue)%QueueForTextRX_maxQueue] == 'C')
              		if(queue->Data[(queue->tail-2+QueueForTextRX_maxQueue)%QueueForTextRX_maxQueue] == 'L')
              			if(queue->Data[(queue->tail-3+QueueForTextRX_maxQueue)%QueueForTextRX_maxQueue] == '#')//change line
              				ChangeLine();
}

// ---------------------------End Queue-------------------------




IFX_INTERRUPT(Uart_AscLin0_RxIsr, 0, ISR_PRIORITY_ASCLIN0_RX);
void Uart_AscLin0_RxIsr()
{
    IfxAsclin_Asc_isrReceive(&AsclinAsc.drivers.asc0);
    AsclinAsc.RxComplete++;

    AsclinAsc.count = UART_TEST_DATA_SIZE;
    IfxAsclin_Asc_read(&AsclinAsc.drivers.asc0, AsclinAsc.Uart_RxData, &AsclinAsc.count, 0xFF);

	QueueForTextRX_Enqueue(&QueueForRx, *((char*)AsclinAsc.Uart_RxData));
    //QueueForTextRX_Enqueue(&QueueForRx, AsclinAsc.drivers.asc0.asclin->RXDATAD.U);
    QueueForTextRX_LED(&QueueForRx);
    __enable();
}




/** \} */

/** \name Interrupts for Error
 * \{ */

IFX_INTERRUPT(Uart_AscLin0_ErIsr, 0, ISR_PRIORITY_ASCLIN0_ER)
{
    IfxAsclin_Asc_isrError(&AsclinAsc.drivers.asc0);
    AsclinAsc.ErComplete++;

}








// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------



App_AsclinAsc AsclinAsc1;


void Uart_Initialization1(void)
{
	static uint8 i;

	/* disable interrupts */
    boolean              interruptState = IfxCpu_disableInterrupts();
    /* create module config */
    IfxAsclin_Asc_Config Uart_AscLin1;
    IfxAsclin_Asc_initModuleConfig(&Uart_AscLin1, &MODULE_ASCLIN1);

    /* set the desired baudrate */
    Uart_AscLin1.baudrate.prescaler    = 1;
    Uart_AscLin1.baudrate.baudrate     = 115200; /* FDR values will be calculated in initModule */
    Uart_AscLin1.baudrate.oversampling = IfxAsclin_OversamplingFactor_4;
    //Uart_AscLin0.clockSource			= 2;

    /* ISR priorities and interrupt target */
    Uart_AscLin1.interrupt.txPriority    = ISR_PRIORITY_ASCLIN1_TX;
    Uart_AscLin1.interrupt.rxPriority    = ISR_PRIORITY_ASCLIN1_RX;
    Uart_AscLin1.interrupt.erPriority    = ISR_PRIORITY_ASCLIN1_ER;
    Uart_AscLin1.interrupt.typeOfService = IfxSrc_Tos_cpu0;

    /* FIFO configuration */
    Uart_AscLin1.txBuffer     = AsclinAsc1.ascBuffer.tx;
    Uart_AscLin1.txBufferSize = ASC_TX_BUFFER_SIZE;

    Uart_AscLin1.rxBuffer     = AsclinAsc1.ascBuffer.rx;
    Uart_AscLin1.rxBufferSize = ASC_RX_BUFFER_SIZE;
    Uart_AscLin1.dataBufferMode = 0;

	const IfxAsclin_Asc_Pins pins1 = {
        NULL,                     IfxPort_InputMode_pullUp,        /* CTS pin not used */
        &IfxAsclin1_RXB_P15_5_IN, IfxPort_InputMode_pullUp,        /* Rx pin */
        NULL,                     IfxPort_OutputMode_pushPull,     /* RTS pin not used */
        &IfxAsclin1_TX_P15_4_OUT, IfxPort_OutputMode_pushPull,     /* Tx pin */
        IfxPort_PadDriver_cmosAutomotiveSpeed1
    };
    Uart_AscLin1.pins = &pins1;

	for(i=0; i<UART_TEST_DATA_SIZE; i++)
	{
		AsclinAsc1.Uart_TxData[i] = i;
	}

    /* initialize module */
    IfxAsclin_Asc_initModule(&AsclinAsc1.drivers.asc0, &Uart_AscLin1);

    /* enable interrupts again */
    IfxCpu_restoreInterrupts(interruptState);



} /* End of Uart_Initialization */



//******************************************************************************
// @Function	 	void Uart_Test(void)
// @Description   	UART communication test
// @Returnvalue		None
// @Parameters    	None
//******************************************************************************


/*
AsclinAsc1.count = UART_TEST_DATA_SIZE;
IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
IfxAsclin_Asc_read(&AsclinAsc1.drivers.asc0, AsclinAsc1.Uart_RxData, &AsclinAsc1.count, 0xFF);

*/


IFX_INTERRUPT(Uart_AscLin0_TxIsr1, 0, ISR_PRIORITY_ASCLIN1_TX)
{
    IfxAsclin_Asc_isrTransmit(&AsclinAsc1.drivers.asc0);
    AsclinAsc1.TxComplete++;
}

/** \} */

/** \name Interrupts for Receive
 * \{ */


int sendStop()
{
	return (int)MODULE_ASCLIN0.FRAMECON.B.STOP;
}




// ----------------------------Queue2 by Hong Hyeon Seok---------------------------
// -------------------------------2016.06.29--------------------------------------
typedef char QueueForTextRX2_Type;
int QueueForTextRX2_maxQueue = 120000;
typedef struct
{
	QueueForTextRX2_Type Data[120000];	// Data[QueueForTextRX_maxQueue]
	uint8 head;
	uint8 tail;
}QueueForTextRX2;

QueueForTextRX2 QueueForRx2;

void QueueForTextRX2_Initialize_ForExtern(void)  // extern void QueueForTextRX2_Initialize_ForExtern(void); should include
{
	QueueForTextRX2_Initialize(&QueueForRx2);
}
void QueueForTextRX2_Initialize(QueueForTextRX2* queue)
{
	queue->tail = QueueForTextRX2_maxQueue-1;
	queue->head = QueueForTextRX2_maxQueue-1;
	int index = 0;
	while(index < QueueForTextRX2_maxQueue)
	{
		queue->Data[index] = '\0';
		index++;
	}
}

boolean QueueForTextRX2_IsEmpty(QueueForTextRX2* queue)
{
	return (queue->tail == queue->head);
}

boolean QueueForTextRX2_IsFull(QueueForTextRX2* queue)
{
	return ((queue->head + 1)%QueueForTextRX2_maxQueue == queue->tail);
}

void QueueForTextRX2_Enqueue(QueueForTextRX2* queue, QueueForTextRX2_Type input)
{
	/*
	if(QueueForTextRX2_IsFull(&queue))
		return;
		*/ // Normal case
	if(QueueForTextRX2_IsFull(queue))
	{
		queue->head = (queue->head + 1)%QueueForTextRX2_maxQueue;
	}
	queue->tail = (queue->tail + 1)%QueueForTextRX2_maxQueue;
	queue->Data[queue->tail] = input;
}

void QueueForTextRX2_Dequeue(QueueForTextRX2* queue, QueueForTextRX2_Type* output)
{
	if(QueueForTextRX2_IsEmpty(queue))
		return;
	queue->head = queue->head+1;
	*output = queue->Data[queue->head];
}

uint8 ImageSizeXX;
uint8 ImageSizeYY;


void QueueForTextRX2_CHECK_ACK(QueueForTextRX2* queue)
{
	if(queue->Data[queue->tail] == 0x00)
    	if(queue->Data[(queue->tail-1+QueueForTextRX2_maxQueue)%QueueForTextRX2_maxQueue] == 0x26)
    		if(queue->Data[(queue->tail-2+QueueForTextRX2_maxQueue)%QueueForTextRX2_maxQueue] == 0x00)
    			if(queue->Data[(queue->tail-3+QueueForTextRX2_maxQueue)%QueueForTextRX2_maxQueue] == 0x76)
    				GLCD_clear(COLOR_BLACK);	// Reset

	if(queue->Data[(queue->tail-2+QueueForTextRX2_maxQueue)%QueueForTextRX2_maxQueue] == 0x00)
		if(queue->Data[(queue->tail-3+QueueForTextRX2_maxQueue)%QueueForTextRX2_maxQueue] == 0x00)
			if(queue->Data[(queue->tail-4+QueueForTextRX2_maxQueue)%QueueForTextRX2_maxQueue] == 0x04)
				if(queue->Data[(queue->tail-5+QueueForTextRX2_maxQueue)%QueueForTextRX2_maxQueue] == 0x00)
					if(queue->Data[(queue->tail-6+QueueForTextRX2_maxQueue)%QueueForTextRX2_maxQueue] == 0x34)
						if(queue->Data[(queue->tail-7+QueueForTextRX2_maxQueue)%QueueForTextRX2_maxQueue] == 0x00)
							if(queue->Data[(queue->tail-8+QueueForTextRX2_maxQueue)%QueueForTextRX2_maxQueue] == 0x76)
							{
								ImageSizeXX = queue->Data[(queue->tail-1+QueueForTextRX2_maxQueue)%QueueForTextRX2_maxQueue];
								ImageSizeYY = queue->Data[queue->tail];
								GLCD_clear(COLOR_MAROON);
								GLCD_displayInt(100,50,ImageSizeXX);
								GLCD_displayInt(100,110,ImageSizeYY);

							}		// ReadDataSize

	if(queue->Data[queue->tail] == 0x00)
		if(queue->Data[(queue->tail-1+QueueForTextRX2_maxQueue)%QueueForTextRX2_maxQueue] == 0x00)
			if(queue->Data[(queue->tail-2+QueueForTextRX2_maxQueue)%QueueForTextRX2_maxQueue] == 0x32)
				if(queue->Data[(queue->tail-3+QueueForTextRX2_maxQueue)%QueueForTextRX2_maxQueue] == 0x00)
					if(queue->Data[(queue->tail-4+QueueForTextRX2_maxQueue)%QueueForTextRX2_maxQueue] == 0x76)
						if(queue->Data[(queue->tail-5+QueueForTextRX2_maxQueue)%QueueForTextRX2_maxQueue] == 0xD9)
							GLCD_clear(COLOR_CYAN);	// ReadData

	if(queue->Data[queue->tail] == 0x00)
		if(queue->Data[(queue->tail-1+QueueForTextRX2_maxQueue)%QueueForTextRX2_maxQueue] == 0x00)
			if(queue->Data[(queue->tail-2+QueueForTextRX2_maxQueue)%QueueForTextRX2_maxQueue] == 0x36)
				if(queue->Data[(queue->tail-3+QueueForTextRX2_maxQueue)%QueueForTextRX2_maxQueue] == 0x00)
					if(queue->Data[(queue->tail-4+QueueForTextRX2_maxQueue)%QueueForTextRX2_maxQueue] == 0x76)
						GLCD_clear(COLOR_LIGHTGREY);	// TakeAphoto
}

// ---------------------------End Queue2-------------------------




void TestImageDataTrams()
{

	unsigned int index = 0;
	/*
	uint16 temp = (uint16)ImageSizeXX;
	temp = temp<<8;
	temp = temp + (uint16)ImageSizeYY;
	*/
	while(index < 120000)
	{
		AsclinAsc.Uart_TxData[0] = QueueForRx2.Data[QueueForRx2.tail - index];
		AsclinAsc.count = 1;
		IfxAsclin_Asc_write(&AsclinAsc.drivers.asc0,AsclinAsc.Uart_TxData, &AsclinAsc.count, TIME_INFINITE);
		index++;
	}

}







uint32 CountDataTrans2 = 0;

IFX_INTERRUPT(Uart_AscLin0_RxIsr1, 0, ISR_PRIORITY_ASCLIN1_RX)
{
    IfxAsclin_Asc_isrReceive(&AsclinAsc1.drivers.asc0);
    AsclinAsc1.RxComplete++;


    AsclinAsc1.count = UART_TEST_DATA_SIZE;
    IfxAsclin_Asc_read(&AsclinAsc1.drivers.asc0, AsclinAsc1.Uart_RxData, &AsclinAsc1.count, 0xFF);

    QueueForTextRX2_Enqueue(&QueueForRx2, *((char*)AsclinAsc1.Uart_RxData));
    QueueForTextRX2_CHECK_ACK(&QueueForRx2);
    CountDataTrans2++;
}

uint32* CountDataTrans2__()
{
	return &CountDataTrans2;
}




/** \} */

/** \name Interrupts for Error
 * \{ */

IFX_INTERRUPT(Uart_AscLin0_ErIsr1, 0, ISR_PRIORITY_ASCLIN1_ER)
{
    IfxAsclin_Asc_isrError(&AsclinAsc1.drivers.asc0);
    AsclinAsc1.ErComplete++;

}







// ---------------------------------SCAM Commands------------------------------------------------
// ---------------------------------2016.06.30. HongHyeonSeok------------------------------------

void SCAM30_Reset()
{
	AsclinAsc1.Uart_TxData[0] = 0x56;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x26;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);

}


void SCAM30_takeAphoto()
{
	AsclinAsc1.Uart_TxData[0] = 0x56;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x36;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x01;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);

}

void SCAM30_ReadImageSize()
{
	AsclinAsc1.Uart_TxData[0] = 0x56;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x34;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x01;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);

}

void SCAM30_ReadImageData(uint16 startIndex)
{
	AsclinAsc1.Uart_TxData[0] = 0x56;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x32;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x0C;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x0A;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = startIndex>>8;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = startIndex;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = ImageSizeXX;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = ImageSizeYY;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0xFF;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);

}

void SCAM30_StopCamera()
{
	AsclinAsc1.Uart_TxData[0] = 0x56;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x36;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x01;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x02;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);

}

void SCAM30_Compressibillity(uint8 Compressibillity)
{
	AsclinAsc1.Uart_TxData[0] = 0x56;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x31;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x05;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x01;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x01;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x12;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x04;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = Compressibillity;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);

}

void SCAM30_SetImageSize(uint16 Mode)
{
	AsclinAsc1.Uart_TxData[0] = 0x56;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x31;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x05;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x04;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x01;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x19;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);


	if(Mode == 320) 	// 320*240;
	{
		AsclinAsc1.Uart_TxData[0] = 0x11;
		AsclinAsc1.count = 1;
		IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
		Delay_ms(1);

	}
	else if(Mode == 640)	// 640*480
	{
		AsclinAsc1.Uart_TxData[0] = 0x00;
		AsclinAsc1.count = 1;
		IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
		Delay_ms(1);

	}
	else if(Mode == 160)	// 160*120
	{
		AsclinAsc1.Uart_TxData[0] = 0x22;
		AsclinAsc1.count = 1;
		IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
		Delay_ms(1);

	}
}

void SCAM30_SleepOn()
{
	AsclinAsc1.Uart_TxData[0] = 0x56;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x3E;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x03;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x01;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x01;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);

}

void SCAM30_SleepOff()
{
	AsclinAsc1.Uart_TxData[0] = 0x56;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x3E;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x03;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x01;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);

}

void SCAM30_ChangeTransferSpeed(uint32 BaudRate)
{
	AsclinAsc1.Uart_TxData[0] = 0x56;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x00;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x24;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x03;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);
	AsclinAsc1.Uart_TxData[0] = 0x01;
	AsclinAsc1.count = 1;
	IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
	Delay_ms(1);

	if(BaudRate == 9600)
	{
		AsclinAsc1.Uart_TxData[0] = 0xAE;
		AsclinAsc1.count = 1;
		IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
		Delay_ms(1);
		AsclinAsc1.Uart_TxData[0] = 0xC8;
		AsclinAsc1.count = 1;
		IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
		Delay_ms(1);
	}
	else if(BaudRate == 19200)
	{
		AsclinAsc1.Uart_TxData[0] = 0x56;
		AsclinAsc1.count = 1;
		IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
		Delay_ms(1);
		AsclinAsc1.Uart_TxData[0] = 0xE4;
		AsclinAsc1.count = 1;
		IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
		Delay_ms(1);
	}
	else if(BaudRate == 38400)
	{
		AsclinAsc1.Uart_TxData[0] = 0x2A;
		AsclinAsc1.count = 1;
		IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
		Delay_ms(1);
		AsclinAsc1.Uart_TxData[0] = 0xF2;
		AsclinAsc1.count = 1;
		IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
		Delay_ms(1);
	}
	else if(BaudRate == 57600)
	{
		AsclinAsc1.Uart_TxData[0] = 0x1C;
		AsclinAsc1.count = 1;
		IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
		Delay_ms(1);
		AsclinAsc1.Uart_TxData[0] = 0x4C;
		AsclinAsc1.count = 1;
		IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
		Delay_ms(1);
	}
	else if(BaudRate == 115200)
	{
		AsclinAsc1.Uart_TxData[0] = 0x0D;
		AsclinAsc1.count = 1;
		IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
		Delay_ms(1);
		AsclinAsc1.Uart_TxData[0] = 0xA6;
		AsclinAsc1.count = 1;
		IfxAsclin_Asc_write(&AsclinAsc1.drivers.asc0,AsclinAsc1.Uart_TxData, &AsclinAsc1.count, TIME_INFINITE);
		Delay_ms(1);
	}

}


