/*
 * TPIM.c
 *
 *  Created on: 2016. 6. 26.
 *      Author: ����
 */
#include "IfxGtm_tim.h"
#include "IfxGtm_PinMap.h"
#include "TIEM.h"
#include "IfxPort.h"
#include "IfxGtm_Cmu.h"
#include "IfxPort_reg.h"
#include "IFxStm_reg.h"
#include "Test_Irq.h"

uint32 Speed;
//#include "IfxGtm_PinMap.h"
Ifx_GTM_TIM *tiem = &MODULE_GTM.TIM[0];
void tim0_TIEM_init(void)
{
	IfxGtm_PinMap_setTimTin(&IfxGtm_TIM0_0_TIN0_P02_0_IN, IfxPort_InputMode_pullUp);
	tiem->CH0.CTRL.B.TIM_MODE 			= IfxGtm_Tim_Mode_inputEvent;
	tiem->CH0.CTRL.B.DSL				= 1;
	tiem->CH0.CTRL.B.ISL				= 0;
	tiem->CH0.CTRL.B.TIM_EN 			= 1; 					// timer enable
	tiem->CH0.CTRL.B.CICTRL	 			= 0;					// TIM CH0 enable
	tiem->CH0.IRQ_EN.B.NEWVAL_IRQ_EN	= 0;
}
uint32 get_tim0_cnt(void)
{
	return Speed;
}
IfxGtm_Tom_Timer Timer;
void encoder_Initialization(void)
{
	/* GTM TOM configuration */
	IfxGtm_Tom_Timer_Config timerConfig;
	//IfxGtm_Tom_Timer timer;
	//App_GtmTomTimer timer;
	IfxGtm_Tom_Timer_initConfig(&timerConfig, &MODULE_GTM);
	timerConfig.base.frequency       = 20;
	timerConfig.base.isrPriority     = ISR_PRIORITY_ENCODER_TIMER;
	timerConfig.base.isrProvider     = 0;
	timerConfig.base.minResolution   = (1.0 / timerConfig.base.frequency) / 1000;
	timerConfig.base.trigger.enabled = FALSE;



	timerConfig.tom                  = IfxGtm_Tom_1;
	timerConfig.timerChannel         = IfxGtm_Tom_Ch_5;
	timerConfig.clock                = IfxGtm_Cmu_Fxclk_4;


	IfxGtm_Tom_Timer_init(&Timer, &timerConfig);
	GTM_TOM1_CH5_SR0.B.SR0 = 1000;
	IfxGtm_Tom_Timer_run(&Timer);
	tim0_TIEM_init();
}

uint32 cntLast=0;
uint16 cnt = 0;
IFX_INTERRUPT (cnt_clear, 0, ISR_PRIORITY_ENCODER_TIMER);
void cnt_clear(void)
{
	cnt++;
	if(cnt == 20)
	{
		P13_OUT.B.P2 = ~P13_OUT.B.P2;
		cnt = 0;
	}
	Speed = (uint32)(tiem->CH0.CNT.U-cntLast+8388607)%8388607;
	cntLast = (uint32)tiem->CH0.CNT.U;
	IfxGtm_Tom_Timer_acknowledgeTimerIrq(&Timer);
	__enable();

}

