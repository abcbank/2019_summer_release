/*
 * Buzzer.c
 *
 *  Created on: 2016. 7. 10.
 *      Author: ����
 */

#include "IfxGtm_tim.h"
#include "IfxGtm_PinMap.h"
#include "IfxPort.h"
#include "IfxGtm_Cmu.h"
#include "IfxPort_reg.h"
#include "IFxStm_reg.h"
#include "Test_Irq.h"
#include "Buzzer.h"
#include "Gtm/Tom/Timer/IfxGtm_Tom_Timer.h"

IfxGtm_Tom_Timer TimerBuzzer;

void buzzer_Initialization(void)
{
	/* GTM TOM configuration */
	IfxGtm_Tom_Timer_Config timerConfig;
	//IfxGtm_Tom_Timer timer;
	//App_GtmTomTimer timer;
	IfxGtm_Tom_Timer_initConfig(&timerConfig, &MODULE_GTM);
	timerConfig.base.frequency       = 1000;
	timerConfig.base.isrPriority     = Buzzer_ISR;
	timerConfig.base.isrProvider     = 0;
	timerConfig.base.minResolution   = (1.0 / timerConfig.base.frequency) / 1000;
	timerConfig.base.trigger.enabled = FALSE;

	timerConfig.tom                  = IfxGtm_Tom_0;
	timerConfig.timerChannel         = IfxGtm_Tom_Ch_3;
	timerConfig.clock                = IfxGtm_Cmu_Fxclk_2;


	IfxGtm_Tom_Timer_init(&TimerBuzzer, &timerConfig);
	GTM_TOM0_CH3_SR0.B.SR0 = 1000;
	IfxGtm_Tom_Timer_run(&TimerBuzzer);

}
uint16 BuzzerCounter = 0;
void BuzzerForShort(void)
{
	BuzzerCounter = 0;
}
IFX_INTERRUPT (BUZZER, 0, Buzzer_ISR);
void BUZZER(void)
{
	if(BuzzerCounter<300){
		BuzzerCounter++;
		P33_OUT.B.P0 = ~P33_OUT.B.P0;
	}
	//P33_OUT.B.P0 = ~P33_OUT.B.P0;
	IfxGtm_Tom_Timer_acknowledgeTimerIrq(&TimerBuzzer);
	__enable();
}



