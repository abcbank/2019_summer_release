
#include "Tricore/Cpu/Std/Ifx_Types.h"
#include "Tricore/Cpu/Std/IfxCpu_Intrinsics.h"
#include "Tricore/Scu/Std/IfxScuWdt.h"
#include <Stm/Std/IfxStm.h>
#include <Port/Std/IfxPort.h>
#include "Test_Irq.h"
#include "Test_ModuleInit.h"

#include "Line_camera_init.h"
#include "Test_Pwm.h"
#include "Test_Adc.h"


#include "Sensor_algorithm.h"


volatile uint16 inittest = 0;
volatile uint16 initStartCount = 0;
volatile uint16 DCon = 0;


void core0_main (void)
{

    __enable ();
    /*
     * !!WATCHDOG0 AND SAFETY WATCHDOG ARE DISABLED HERE!!
     * Enable the watchdog in the demo if it is required and also service the watchdog periodically
     * */
    IfxScuWdt_disableCpuWatchdog (IfxScuWdt_getCpuWatchdogPassword ());
    IfxScuWdt_disableSafetyWatchdog (IfxScuWdt_getSafetyWatchdogPassword ());

    Test_ModuleInit();
    init_camera();

    while (1)
    {

    	if(inittest==1)
    	{

    		linescan_Camara();
    		Test_VadcAutoScan(IfxVadc_GroupId_0);
        	if(DCon>=1)
        	{
        		if (DCon >=3)
        		{
        			shcool_check();
        		}

    			IR_check();
    			mode_check();
        		if(linescan_Irdy == 1)
        		{

        			servo_control(MODE_sel);
        			DC_control(MODE_sel);
        			linescan_Irdy =0;
        		}
        	}
        	else
        	{
        		Pwm_MotorDutyAndDirectionControl(0,0);
        	}

    		inittest=0;
    		linescan_Irdy =0;
    	}
    }
}

void SecondTimer_Initialization(void)
{
    volatile float       stm_freq;
    Ifx_STM             *stm = &MODULE_STM0;
    IfxStm_CompareConfig stmCompareConfig;

    /* suspend by debugger enabled */
    IfxStm_enableOcdsSuspend(stm);
    /* get current STM frequency : debug purpose only*/
    stm_freq = IfxScuCcu_getStmFrequency();
    /* constructor of configuration */
    IfxStm_initCompareConfig(&stmCompareConfig);
	stmCompareConfig.triggerPriority = ISR_PRIORITY_STM;
	stmCompareConfig.ticks = 100000000;
	stmCompareConfig.typeOfService = IfxSrc_Tos_cpu0;
    /* Now Compare functionality is initialized */
    IfxStm_initCompare(stm, &stmCompareConfig);

} // End of TaskScheduler_Initialization()

//*********************************************************************************************
// @Function	 	void UsrIsr_Stm_0(void)
// @Description   	STM0 Interrupt for system tick generation
// @Returnvalue		None
// @Parameters    	None
//*********************************************************************************************
IFX_INTERRUPT (SecondTimer_Isr, 0, ISR_PRIORITY_STM);
void SecondTimer_Isr(void)
{
    Ifx_STM *stm = &MODULE_STM0;

    /* Set next *ms scheduler tick alarm */
    IfxStm_updateCompare(stm, IfxStm_Comparator_0, IfxStm_getLower(stm) + 2000000);//20ms

    initStartCount++;



	inittest = 1;

	Front_sensor();

	if(initStartCount>50)
    {

        P13_OUT.B.P3 = !P13_OUT.B.P3;
        P13_OUT.B.P1 = !P13_OUT.B.P1;

    	initStartCount = 0;
    		if (DCon <= 3)
    		{
    			DCon++;
    		}
    }


    __enable();

}




