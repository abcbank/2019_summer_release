/*
 * Line_camera_init.c
 *
 *  Created on: 2016. 6. 4.
 *      Author: kk
 */

#include "stdio.h"
#include "Line_camera_init.h"
#include "Test_Adc.h"
#include "Test_Pwm.h"

volatile uint16  *linescanI0WB;
volatile uint16  *linescan_I0;
volatile uint16  linescan_I0B[2][128];
volatile uint16  *linescanI1WB;
volatile uint16  *linescan_I1;
volatile uint16  linescan_I1B[2][128];

volatile uint8  linescan_WB;
volatile uint8 linescan_Irdy = 0;

uint8 right_speed_limit_Zone = 0;
uint8 left_speed_limit_Zone = 0;

uint16 Max_Value[2]={0};
uint16 Min_Value[2]={3000};
uint16 Filtering_data0[128];
uint16 Filtering_data1[128];

void overwatch( uint16 *A ,uint8 select_camera);
int get_number(int num1, int num2, int num3, int num4, int num5);

void init_camera(void);

void init_camera()
{
	linescan_WB = 0;
	linescanI0WB = &linescan_I0B[0][0];
	linescan_I0 = &linescan_I0B[1][0];
	linescanI1WB = &linescan_I1B[0][0];
	linescan_I1 = &linescan_I1B[1][0];
}

void linePulse_Clk(void)
{
   P22_OUT.B.P0 = 1;
   P22_OUT.B.P2 = 1;
   Delay_us(4);
   P22_OUT.B.P0 = 0;
   P22_OUT.B.P2 = 0;
   Delay_us(4);
}
void linePulse_Si(void)
{
   P22_OUT.B.P1 = 1;
   P22_OUT.B.P3 = 1;
   Delay_us(2);
   P22_OUT.B.P0 = 1;
   P22_OUT.B.P2 = 1;
   Delay_us(2);
   P22_OUT.B.P1 = 0;
   P22_OUT.B.P3 = 0;
   Delay_us(2);
   P22_OUT.B.P0 = 0;
   P22_OUT.B.P2 = 0;
   Delay_us(2);
}

void linescan_Camara(void)
{
   uint8 i;
   uint16 black[2]={0};
   Max_Value[0]=0;
   Max_Value[1]=0;

   if(linescan_Irdy==0)
   {

	   P22_OUT.B.P1 = 1;
	   P22_OUT.B.P3 = 1;
	   Delay_us(12);
	   P22_OUT.B.P0 = 1;
	   P22_OUT.B.P2 = 1;
	   Delay_us(12);
	   P22_OUT.B.P1 = 0;
	   P22_OUT.B.P3 = 0;
	   Delay_us(12);
	   P22_OUT.B.P0 = 0;
	   P22_OUT.B.P2 = 0;
	   Delay_us(25);

	   linescanI0WB[0] = VadcAutoScan_camera(IfxVadc_GroupId_0,0);
	   linescanI1WB[0] = VadcAutoScan_camera(IfxVadc_GroupId_0,1);

	   for(i=1;i<128;i++)
	   {

		   P22_OUT.B.P0 = 1;
		   P22_OUT.B.P2 = 1;
		   Delay_us(25);
		   P22_OUT.B.P0 = 0;
		   P22_OUT.B.P2 = 0;
		   Delay_us(25);

		   linescanI0WB[i] = VadcAutoScan_camera(IfxVadc_GroupId_0,0);
		   linescanI1WB[i] = VadcAutoScan_camera(IfxVadc_GroupId_0,1);

		   if(Max_Value[0]<linescanI0WB[i])
		   {
			   Max_Value[0]=linescanI0WB[i];
		   }
		   if(Max_Value[1]<linescanI1WB[i])
		   {
			   Max_Value[1]=linescanI1WB[i];
		   }

		   if(linescanI0WB[i]<	500)
		   {
			   black[0]++;
		   }
		   if(linescanI1WB[i]<	500)
		   {
			   black[1]++;
		   }


	   }
		if(linescan_WB == 0)
	   {
		   linescan_WB = 1;

		   linescanI0WB = &linescan_I0B[1][0];//
		   linescan_I0 = &linescan_I0B[0][0];
		   linescanI1WB = &linescan_I1B[1][0];
		   linescan_I1 = &linescan_I1B[0][0];
	   }
	   else
	   {
		   linescan_WB = 0;

		   linescanI0WB = &linescan_I0B[0][0];//
		   linescan_I0 = &linescan_I0B[1][0];
		   linescanI1WB = &linescan_I1B[0][0];
		   linescan_I1 = &linescan_I1B[1][0];
	   }
	   if(black[0]<50 && black[1]<50 )
	   {
		   overwatch(linescan_I0,0);
		   overwatch(linescan_I1,1);

	   }

	   black[0]=0;
	   black[1]=0;

	   linescan_Irdy = 1;
   }

}



void overwatch( uint16 *A , uint8 select_camera )
{
   int i;
   int B[128]={0};
   uint16 temp;

   for(i=0;i<128;i++)
   {

      if ( i== 0 )
      {
         B[i]=get_number(9999, 9999, A[i], A[i+1], A[i+2]);
      }
      else if ( i== 1)
      {
         B[i]=get_number(9999, B[i-1], A[i], A[i+1], A[i+2]);
      }
      else if ( i== 126 )
      {
         B[i]=get_number(B[i-2], B[i-1], A[i], A[i+1], 9999);
      }
      else if ( i== 127 )
      {
         B[i]=get_number(B[i-2], B[i-1], A[i], 9999,9999);
      }
      else
      {
         B[i]=get_number(B[i-2], B[i-1], A[i], A[i+1], A[i+2]);
      }
   }


   for(i=0;i<128;i++)
   {
	   if(i>125)
	   {
		   temp=abs((B[i-2]-B[i])/2);
	   }
	   else
	   {
		   temp=abs((B[i+2]-B[i])/2);
	   }

	   if(select_camera==0)
	   {
		   Filtering_data0[i]=temp;
	   }
	   else
	   {
		   Filtering_data1[i]=temp;
	   }
   }

}



int get_number(int num1, int num2, int num3, int num4, int num5)
{
   int x;
   int y;
   int lol=0;
   int z ;
   int temp;

   int C[5]={0};

   if ( num1 != 9999 )
   {
      C[lol++]=num1;
   }
   if ( num2 != 9999 )
   {
      C[lol++]=num2;
   }
   C[lol++]=num3;
   if ( num4 != 9999 )
   {
      C[lol++]=num4;
   }
   if ( num5 != 9999 )
   {
      C[lol++]=num5;
   }




   for(x=0;x<lol;x++)
   {
      for(y=0;y<lol-x-1;y++)
      {
         if (C[y]>C[y+1])
         {
            temp=C[y];
            C[y]=C[y+1];
            C[y+1]=temp;
         }
      }
   }


   if ( lol < 5 )
      z=C[1];
   else
      z=C[2];

   return z;
}
