/*
 * sensor_algorithm.c
 *
 *  Created on: 2016. 6. 9.
 *      Author: kk
 */
#include "Sensor_algorithm.h"
#include "math.h"
#include "stdio.h"
#include "IfxPort.h"
//  �� 602 1.505ms      �� 750  1.875ms       �� 866   2.165ms

#define PI 3.1415

//uint16 PWM_angle[2][85]={{750,752,754,756,758,760,762,764,766,768,770,772,774,776,778,780,782,784,786,788,790,792,794,796,798,800,802,804,806,808,810,812,814,816,818,820,822,824,826,828,830,832,834,836,838,840,842,844,846,848,850,852,854,856,858,860,862,864,866,868,870,870,	874,	878,	882,	886,	890,	894,	898,	902,	906,	910,	914,	918,	922,	926,	930,	934,	938,	942,	946,	950,	954,	958,	962},
//		                 {750,748,746,744,742,740,738,736,734,732,730,728,726,724,722,720,718,716,714,712,710,708,706,704,702,700,698,696,694,692,690,688,686,684,682,680,678,676,674,672,670,668,666,664,662,660,658,656,654,652,650,648,646,644,642,640,638,636,634,632,630,602,	598,	594,	590,	586,	582,	578,	574,	570,	566,	562,	558,	554,	550,	546,	542,	538,	534,	530,	526,	522,	518,	514,	510}};
/*
uint16 PWM_angle[2][86]={{750,	751,	752,	753,	754,	755,	756,	757,	758,	759,	760,	763,	766,	769,	772,	775,	778,	781,	784,	787,	790,	793,	796,	799,	802,	805,	808,	811,	815,	819,	823,	827,	831,	835,	839,	844,	849,	854,	859,	864,	869,	873,	877,	881,	885,	889,	893,	896,	899,	902,	905,	908,	911,	914,	917,	920,	923,	926,	929,	932,	934,	936,	938,	940,	942,	944,	946,	948,	950,	951,	952,	953,	954,	955,	956,	957,	958,	959,	960,	961,	962,	963,	964,	965,	966,	967	},
						 {750,	749,	748,	747,	746,	745,	744,	743,	742,	741,	740,	737,	734,	731,	728,	725,	722,	719,	716,	713,	710,	707,	704,	701,	698,	695,	692,	689,	685,	681,	677,	673,	669,	665,	661,	656,	651,	646,	641,	636,	631,	627,	623,	619,	615,	611,	607,	604,	601,	598,	595,	592,	589,	586,	583,	580,	577,	574,	571,	568,	566,	564,	562,	560,	558,	556,	554,	552,	550,	549,	548,	547,	546,	545,	544,	543,	542,	541,	540,	539,	538,	537,	536,	535,	534,	533}};
*/
uint16 PWM_angle[2][86]={{740,   741,   742,   743,   744,   746,   748,   750,   752,   754,   756,   759,   762,   765,   768,   771,   774,   777,   780,   783,   786,   789,   792,   795,   798,   801,   804,   807,   811,   815,   819,   823,   827,   831,   835,   840,   845,   850,   855,   860,   865,   869,   873,   877,   881,   885,   889,   892,   895,   898,   901,   904,   907,   910,   913,   916,   919,   922,   925,   928,   930,   932,   934,   936,   938,   940,   942,   944,   946,   947,   948,   949,   950,   951,   952,   953,   954,   955,   956,   957,   958,   959,   960,   961,   962,   963	},
						 {740,   739,   738,   737,   736,   734,   732,   730,   728,   726,   724,   721,   718,   715,   712,   709,   706,   703,   700,   697,   694,   691,   688,   685,   682,   679,   676,   673,   669,   665,   661,   657,   653,   649,   645,   640,   635,   630,   625,   620,   615,   611,   607,   603,   599,   595,   591,   588,   585,   582,   579,   576,   573,   570,   567,   564,   561,   558,   555,   552,   550,   548,   546,   544,   542,   540,   538,   536,   534,   533,   532,   531,   530,   529,   528,   527,   526,   525,   524,   523,   522,   521,   520,   519,   518,   517}};
////////�ӵ����� ����///////////
uint8 schoolcheck = 0;
uint8 schoolcheck_val=0;
uint8 emergency_check=0;
uint8 schoolcheck_buf;
uint8 current_lane;
/////////���üũ/////////////
uint8 hill_check_last;
uint8 hillcheck;
uint8 hill_check_current;

/////////���ع�//////////////
uint8 obstaclescheck;
//////////////////////////
uint8 MODE_sel;

uint16 hill_check_val;
uint16 obstacles_check_val;


uint16 lefthitpoint;
uint16 righthitpoint;
uint8 center_length=100;
uint8 Before_angle=0;
uint8 Before_numb_angle=0;
double caculationhitpoint2;

uint8 speedlimitstack=0;

uint8 speedlimitslow_down;

uint8 slow_down=0;
uint8 slow_300=0;
uint8 return_line=0;

uint8 return_line_stack=0;

uint8 obstacles_stack=0;

void Front_sensor(void);
void shcool_check(void);
void IR_check(void);
void mode_check(void);
void servo_control(uint8 mode_sel);



void Front_sensor(void)
{
	uint16 black_check_val[2]={0};

	black_check_val[0]= IfxPort_getPinState(&MODULE_P00,5);
	black_check_val[1]= IfxPort_getPinState(&MODULE_P00,6);


	if(black_check_val[0]==1 && black_check_val[1]==1)
	{
		schoolcheck_val=1;
		emergency_check=0;
		right_speed_limit_Zone=0;
		left_speed_limit_Zone=0;
	}
	else if(black_check_val[0]==0 && black_check_val[1]==1 && hillcheck != 1 && right_speed_limit_Zone != 1)
	{
//		emergency_check=1; //������ ���� ��ȸ�� ���
	}
	else if(black_check_val[0]==1 && black_check_val[1]==0 && hillcheck != 1 && left_speed_limit_Zone != 1)
	{
//		emergency_check=2; //���� ���� ��ȸ�� ���
	}
	else if(black_check_val[0]==0 && black_check_val[1]==0)
	{
		MODE_sel=0;
		schoolcheck_val=0;
		emergency_check=0;
	}

}

void shcool_check(void)
{
	if(schoolcheck==0 && schoolcheck_val==0 && schoolcheck_buf==1 && hillcheck != 1 )
	{

		schoolcheck=1;
	}
	else if(schoolcheck==1 && schoolcheck_val==0 && schoolcheck_buf==1)
	{
		schoolcheck=0;
		return_line = 1;
		speedlimitstack=0;
	}
	schoolcheck_buf=schoolcheck_val;
}

void IR_check(void)
{

	hill_check_val		= Adc_Result_Scan[0][0];
	obstacles_check_val	= Adc_Result_Scan[0][1];


	if(hill_check_val>1300&&obstacles_check_val<900)
	{
		hill_check_current=1;

	}
	else
	{
		hill_check_current=0;

	}

	if(hillcheck==0 && hill_check_current==1 && hill_check_last==0)
	{
		hillcheck=1;
	}
	else if(hillcheck==1 && hill_check_current==1 && hill_check_last==0)
	{
		hillcheck=0;
		P13_OUT.B.P4 = 0;
	}

	hill_check_last=hill_check_current;


	if (schoolcheck == 1 && obstacles_check_val > 500 )
	{
		obstacles_stack++;
		if(obstacles_stack>=2)
		{
			obstaclescheck = 1;
		}
	}
	else if(schoolcheck !=1 && obstacles_check_val>500)
	{
		obstacles_stack++;
		if(obstacles_stack>=2)
		{
			obstaclescheck = 1;
		}
	}
	else
	{
		obstaclescheck=0;
		obstacles_stack=0;
	}

	if(obstacles_check_val>=300)
	{
		slow_300 = 1;
	}
	else
	{
		slow_300 = 0;
	}


}



void mode_check(void)
{


		if(schoolcheck != 1 && obstaclescheck == 1)
		{
			MODE_sel=4; //����
		}
		else if(schoolcheck == 1 && obstaclescheck == 1)
		{
			MODE_sel=3; // �ӵ����ѱ���ȸ��
		}
		else if(schoolcheck == 1 && obstaclescheck != 1)
		{
			MODE_sel=1; // ������
		}
		else if(schoolcheck != 1 && emergency_check > 0)
		{
			MODE_sel=2; // ��� ȸ��

		}
		else if(schoolcheck != 1 && hillcheck == 1)
		{
			MODE_sel=5; //���
		}
		else
		{
			MODE_sel=0; //�Ϲ�
		}



}





void servo_control(uint8 mode_sel)
{
	int i;
	int left_point;
	int right_point;
	int hit_point;
	double angle;
	uint8 numb_angle;

	for(i=57;i<128;i++)
	{
		if(Filtering_data0[i]>200)
		{
			right_point = i;
			i = 128;
		}
		else
		{
			right_point = 127;
		}
	}


	 righthitpoint=right_point;//���߿� ����


	for(i=69;i>=0;i--)
	{
		if(Filtering_data1[i]>(Max_Value[1]/7))
		{
			left_point = i;
			i = -1;
		}
		else
		{
			left_point = 0;
		}
	}

	lefthitpoint=left_point;//���߿� ����

	hit_point = (((left_point+right_point)/2)-64);
	angle	  = atan2(hit_point,36)*180/PI;
	numb_angle= abs((int)angle);




	if(numb_angle>85)
	{
		numb_angle=85;
	}



	if (numb_angle >15 )
	{
		slow_down = 1;
		speedlimitslow_down=1;
	}
	else
	{
		slow_down = 0;
		speedlimitslow_down=0;

	}

	if(return_line==1 && current_lane==1)
	{
		MODE_sel=1;
		return_line_stack++;
		if(return_line_stack==5)
		{
			while(!IfxPort_getPinState(&MODULE_P00,5))
			{
				Pwm_servo(PWM_angle[0][42]);
			}
			current_lane		=	0;
			return_line			=	0;
			return_line_stack	=	0;
		}

	}


		switch (mode_sel)
		{

				case 0:

					if(angle<=0)
					{
						Pwm_servo(PWM_angle[1][numb_angle]);
					}
					else if(angle>=0)
					{
						Pwm_servo(PWM_angle[0][numb_angle]);
					}

					break;


				case 1:

						if(angle<0)
						{
							Pwm_servo(PWM_angle[1][numb_angle]);
						}
						else
						{
							Pwm_servo(PWM_angle[0][numb_angle]);
						}




					break;

				case 2:

					if(emergency_check == 1)
					{
						Pwm_servo(PWM_angle[1][80]);
					}
					else if(emergency_check == 2)
					{
						Pwm_servo(PWM_angle[0][80]);
					}

					break;

				case 3:

					if(current_lane==1)
					{
						while(!IfxPort_getPinState(&MODULE_P00,5))
						{
							Pwm_servo(PWM_angle[0][42]);
						}
						current_lane=0;
						MODE_sel=1;
					}
					else if(current_lane==0)
					{
						while(!IfxPort_getPinState(&MODULE_P00,6))
						{
							Pwm_servo(PWM_angle[1][42]);
						}
						current_lane=1;
						MODE_sel=1;
					}
					break;

				case 4:

					if(angle<0)
					{
						Pwm_servo(PWM_angle[1][numb_angle]);
					}
					else
					{
						Pwm_servo(PWM_angle[0][numb_angle]);
					}

					break;

				case 5:
					P13_OUT.B.P4 = 1;

					if(angle<=0)
					{
						Pwm_servo(PWM_angle[1][numb_angle]);
					}
					else if(angle>=0)
					{
						Pwm_servo(PWM_angle[0][numb_angle]);
					}

					break;

				default:

					break;
		}

			 caculationhitpoint2=angle;

}






