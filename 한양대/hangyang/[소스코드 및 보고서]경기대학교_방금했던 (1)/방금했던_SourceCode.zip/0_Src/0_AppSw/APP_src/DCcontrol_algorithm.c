/*
 * DCcontrol_algorithm.c
 *
 *  Created on: 2016. 6. 9.
 *      Author: kk
 */
#include "DCcontrol_algorithm.h"



uint8 curvestack = 0;
double curve_goal = 2.0;



void DC_control(uint8 mode_sel)
{

	switch(mode_sel)
	{

	case 4:
		PID_control(encodertick, -1);
		break;
	case 1:

		/*if (speedlimitslow_down == 1)
		{

					if (curvestack >=50)
					{
						B_PID(encodertick, 1.9);
					}
					else
					{
						B_PID(encodertick,3.4);
						curvestack++;
					}
		}
		else
		{
			curvestack = 0;
			PID_control(encodertick, 1.9);
		}*/
		PID_control(encodertick, 2.2);
		break;
	default :

		if (slow_down == 1)
		{

			if (curvestack >=30)
			{
				B_PID(encodertick, 3.4);
			}

			else
			{
				B_PID(encodertick,2);
				curvestack++;
			}

		}
		else if (slow_300 ==1)
		{
			PID_control(encodertick, 2);
		}
		else
		{
			curvestack = 0;
			PID_control(encodertick , 4.3);

		}

		break;
	}

}
