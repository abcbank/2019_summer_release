/*
 * Test_encoder.c
 *
 *  Created on: 2016. 6. 2.
 *      Author: kk
 */


#include <stdio.h>

#include "Test_encoder.h"
#include "Test_Irq.h"

#include "IfxGtm_reg.h"
#include "IfxSrc_reg.h"
#include "IfxSrc_cfg.h"
#include "IfxGtm_PinMap.h"
#include "IfxGtm_bf.h"

double lasterror =0;
double Blasterror =0;




unsigned int encodertick  = 0;

signed int duuutycycle;
App_GtmTimInput GtmTiminput;



IFX_INLINE Ifx_GTM_TIM_CH *IfxGtm_Tim_Ch_getChannelPointer(Ifx_GTM_TIM *tim, IfxGtm_Tom_Ch channel)
{
    return (Ifx_GTM_TIM_CH *)((uint32)&tim->CH0.CTRL.U + 0x80 * channel);
}
volatile Ifx_SRC_SRCR *IfxGtm_Tim_Ch_getSrcPointer(IfxGtm_Tim tim, IfxGtm_Tim_Ch channel)
{
    return &MODULE_SRC.GTM.GTM[0].TIM[tim][channel];
}
void IfxGtm_Tim_Ch_setNotification(Ifx_GTM_TIM *tim, IfxGtm_Tom_Ch channel, IfxGtm_IrqMode mode)
{

    Ifx_GTM_TIM_CH_IRQ_EN en;



    GTM_TIM0_CH0_IRQ_EN.U		= IFX_ZEROS;
    GTM_TIM0_CH0_IRQ_MODE.B.IRQ_MODE = mode;  // 2 �ȵǸ�  0
    en.B.NEWVAL_IRQ_EN        	= TRUE;
    GTM_TIM0_CH0_IRQ_EN.U		= en.U;

}


void B_PID(uint16 tickcheck,double goal)

{

	GTM_TIM0_CH0_CTRL.B.TIM_EN=0;

	  double Bcurrent = 0;
	  double Btimediff;
	  double Berror;
	  double Baccumulate;
	  double Bdivision;
	  double Bkp = 1.6;
	  double Bki = 0.5;
	  double Bkd = 0.3;
	  double Bkperr;
	  double Bkierr;
	  double Bkderr;
	  double BPID_PWM=0;




	  Btimediff = 0.02;


	  Bcurrent =(( uint16)tickcheck/100)*0.28 / Btimediff;

	  Berror = goal - Bcurrent;


	  Baccumulate = (float) Berror * Btimediff;
	  Bdivision = (Berror - Blasterror) / Btimediff;

	  Bkperr = Bkp * Berror;
	  Bkierr = Bki * Baccumulate;
	  Bkderr = Bkd * Bdivision;

	  BPID_PWM = Bkperr + Bkierr + Bkderr;
	  if  (BPID_PWM >=8.333)
	   {
	   BPID_PWM = 8.333;
	   duuutycycle = 2000;
	   }

	   else
	   {
	   duuutycycle =BPID_PWM/0.004165;
	   }


	   Blasterror = Berror;


	 if (duuutycycle<0)
	 {
	 	 duuutycycle = abs(duuutycycle);
	 	 Pwm_MotorDutyAndDirectionControl(duuutycycle,1);
	 }
	 else
	 {
		Pwm_MotorDutyAndDirectionControl(duuutycycle,0);
	 }


	GTM_TIM0_CH0_CTRL.B.TIM_EN=1;
}




void PID_control(uint16 tickcheck,double goal)
{



	GTM_TIM0_CH0_CTRL.B.TIM_EN=0;

	  double current = 0;
	  double timediff;
	  double error;
	  double accumulate;
	  double division;
	  double kp = 1.6;
	  double ki = 0.5;
	  double kd = 0.3;
	  double kperr;
	  double kierr;
	  double kderr;
	  double PID_PWM=0;




	  timediff = 0.02;


	  current =(( uint16)tickcheck/100)*0.28 / timediff;


	  error = goal - current;


	  accumulate = (float) error * timediff;
	  division = (error - lasterror) / timediff;

	  kperr = kp * error;
	  kierr = ki * accumulate;
	  kderr = kd * division;

	  PID_PWM = kperr + kierr + kderr;



	  if  (PID_PWM >=8.333)
	   {
	   PID_PWM = 8.333;
	   duuutycycle = 2000;
	   }

	   else
	   {
	   duuutycycle =PID_PWM/0.004165;
	   }


	   lasterror = error;




	 if (duuutycycle<0)
	 {
	 	 duuutycycle = abs(duuutycycle);
	 	 Pwm_MotorDutyAndDirectionControl(duuutycycle,1);
	 }
	 else
	 {
		Pwm_MotorDutyAndDirectionControl(duuutycycle,0);
	 }


	GTM_TIM0_CH0_CTRL.B.TIM_EN=1;
}


IFX_INTERRUPT(Inputcapture_irq, 0, ISR_PRIORITY_GTM_TIM0_0_ICU);
void Inputcapture_irq(void)
{
	boolean result;


    IfxCpu_enableInterrupts();

    result = GTM_TIM0_CH0_IRQ_NOTIFY.B.NEWVAL != 0;
    if(result)
    {
    	GTM_TIM0_CH0_IRQ_NOTIFY.B.NEWVAL = 1;
    }
    else
    {}

    encodertick = GTM_TIM0_CH0_CNT.B.CNT;


}

void Gtm_Tim_init(Inputcapture_Config *driver,const IfxGtm_Tim_capture_Config *config)
{
    driver->gtm          = config->gtm;
    driver->timIndex     = config->tim;
    driver->tim          = &config->gtm->TIM[config->tim];
    driver->captureChannel = config->captureChannel;

	IfxGtm_PinMap_setTimTin(config->tim_pointer,config->base.inputMode);



    /* Interrupt configuration */

	volatile Ifx_SRC_SRCR *src;

	IfxGtm_IrqMode irqMode = IfxGtm_IrqMode_pulseNotify;

	IfxGtm_Tim_Ch_setNotification(driver->tim, driver->captureChannel, irqMode);
	src = IfxGtm_Tim_Ch_getSrcPointer(config->tim, driver->captureChannel);
	IfxSrc_init(src, config->base.isrProvider, config->base.isrPriority);
	IfxSrc_enable(src);


}

void inputcaptureinitialize(){


	GTM_TIM0_CH0_CTRL.B.TIM_EN=0;
	GTM_TIM0_CH0_CTRL.B.TIM_MODE=2;
	GTM_TIM0_CH0_CTRL.B.OSM=0;
	GTM_TIM0_CH0_CTRL.B.CICTRL=0;
	GTM_TIM0_CH0_CTRL.B.EGPR0_SEL=0;
	GTM_TIM0_CH0_CTRL.B.GPR0_SEL=3;
	GTM_TIM0_CH0_CTRL.B.EGPR1_SEL=0;
	GTM_TIM0_CH0_CTRL.B.GPR1_SEL=3;
	GTM_TIM0_CH0_CTRL.B.ISL=0;
	GTM_TIM0_CH0_CTRL.B.DSL=1;
	GTM_TIM0_CH0_CTRL.B.EXT_CAP_EN=0;
	GTM_TIM0_CH0_CTRL.B.CLK_SEL=0;
	GTM_TIM0_CH0_CTRL.B.FLT_EN=1;
	GTM_TIM0_CH0_ECTRL.B.EXT_CAP_SRC=0;//3;
	GTM_TIM0_CH0_FLT_RE.B.FLT_RE=5000;
	GTM_TIM0_CH0_FLT_FE.B.FLT_FE=5000;



	GTM_TIM0_CH0_IRQ_MODE.B.IRQ_MODE=2;
	SRC_GTM_GTM0_TIM0_0.B.SRPN= ISR_PRIORITY_GTM_TIM0_0_ICU;
	SRC_GTM_GTM0_TIM0_0.B.TOS= IfxSrc_Tos_cpu0;
	SRC_GTM_GTM0_TIM0_0.B.CLRR=1;
	GTM_ICM_IRQG_2.B.TIM0_CH0_IRQ=1;
	GTM_TIM0_CH0_IRQ_EN.B.NEWVAL_IRQ_EN=1;
	SRC_GTM_GTM0_TIM0_0.B.SRE=1;

	IfxGtm_Tim_capture_Config Timconfig;
	IfxGtm_Tim_TinMapP tim_pointer = &IfxGtm_TIM0_0_TIN32_P33_10_IN;

	Timconfig.base.inputMode	=	IfxPort_InputMode_noPullDevice;
	Timconfig.tim_pointer		= 	tim_pointer;
	Timconfig.base.isrPriority 	= 	ISR_PRIORITY_GTM_TIM0_0_ICU;
	Timconfig.base.isrProvider	= 	0;
	Timconfig.tim              	= 	IfxGtm_Tim_0;
	Timconfig.captureChannel    = 	IfxGtm_Tim_Ch_0;

	Dio_Configuration(&MODULE_P33, 10, IfxPort_InputMode_noPullDevice,IfxPort_PadDriver_cmosAutomotiveSpeed1,IfxPort_State_notChanged);

	Gtm_Tim_init(&GtmTiminput.drivers.timinputcapture,&Timconfig);



	GTM_TIM0_CH0_CTRL.B.TIM_EN=1;
}
