/*
 * Line_camera_init.h
 *
 *  Created on: 2016. 6. 4.
 *      Author: kk
 */

#ifndef _LINE_CAMERA_INIT_H_
#define _LINE_CAMERA_INIT_H_

#include <Port/Std/IfxPort.h>
#include "Tricore/Cpu/Std/Ifx_Types.h"

extern volatile uint16  *linescanI0WB;
extern volatile uint16  *linescanI1WB;


extern volatile uint16 *linescan_I0;
extern volatile uint16 *linescan_I1;

extern uint16 Max_Value[2];
extern uint16 Min_Value[2];
extern volatile uint16  linescan_I0B[2][128];
extern volatile uint16  linescan_I1B[2][128];


extern volatile uint8 linescan_WB;
extern volatile uint8  linescan_Irdy;

extern uint16 Filtering_data0[128];
extern uint16 Filtering_data1[128];

extern uint8 right_speed_limit_Zone;
extern uint8 left_speed_limit_Zone;
/////////////////////////////////////////
extern void linescan_Camara(void);
extern void init_camera(void);
#endif /* 0_SRC_0_APPSW_APP_INC_LINE_CAMERA_INIT_H_ */
