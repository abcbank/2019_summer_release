/*
 * DCcontrol_algorithm.h
 *
 *  Created on: 2016. 6. 9.
 *      Author: kk
 */

#ifndef DCCONTROL_ALGORITHM_H_
#define DCCONTROL_ALGORITHM_H_

#include <Port/Std/IfxPort.h>
#include "Tricore/Cpu/Std/Ifx_Types.h"
#include "Test_encoder.h"
extern void DC_control(uint8 mode_sel);
#include "Sensor_algorithm.h"
#endif /* 0_SRC_0_APPSW_APP_INC_DCCONTROL_ALGORITHM_H_ */
