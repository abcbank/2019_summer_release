/*
 * sensor_algorithm.h
 *
 *  Created on: 2016. 6. 9.
 *      Author: kk
 */

#ifndef SENSOR_ALGORITHM_H_
#define SENSOR_ALGORITHM_H_


#include <Port/Std/IfxPort.h>
#include "Tricore/Cpu/Std/Ifx_Types.h"
#include "Test_Adc.h"
#include "Line_camera_init.h"
#include "Test_Pwm.h"

extern void Front_sensor(void);
void shcool_check(void);
void IR_check(void);
void mode_check(void);
void servo_control(uint8 mode_sel);

extern uint8 speedlimitslow_down;
extern uint8 schoolcheck ;
extern uint16 hill_check_val;
extern uint16 obstacles_check_val;
extern uint8 MODE_sel;
extern uint8 slow_down;
extern uint8 slow_300;

#endif /* 0_SRC_0_APPSW_APP_INC_SENSOR_ALGORITHM_H_ */
