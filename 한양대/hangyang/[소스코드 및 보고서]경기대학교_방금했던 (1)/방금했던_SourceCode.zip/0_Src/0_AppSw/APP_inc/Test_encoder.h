/*
 * Test_encoder.h
 *
 *  Created on: 2016. 5. 25.
 *      Author: kk
 */

#ifndef TEST_ENCODER_H_
#define TEST_ENCODER_H_

#include <Ifx_Types.h>

#include "SysSe/Bsp/Bsp.h"
#include "IfxGtm_bf.h"
#include "IfxPort_reg.h"

#include "IfxGtm_reg.h"
#include "IfxSrc_reg.h"
#include "IfxSrc_cfg.h"
#include "IfxGtm_PinMap.h"



extern void inputcaptureinitialize(void);
extern void PID_control(uint16 tickcheck,double goal);//l,uint16 direction);
extern void B_PID(uint16 tickcheck,double goal);
extern unsigned int encodertick;

typedef IfxGtm_Tim_TinMap *IfxGtm_Tim_TinMapP;



typedef struct
{
    float32            deadtime;            /**< \brief Dead time between the top and bottom channels in seconds */
    float32            minPulse;            /**< \brief Min pulse allowed as active state for the top and bottom PWM in seconds */
    uint8              channelCount;        /**< \brief Number of PWM channels, one channel is made of a top and bottom channel */
    boolean            emergencyEnabled;    /**< \brief Specifies if the emergency stop should be enabled or not */

    IfxPort_InputMode inputMode;          /**< \brief Output mode of ccx and coutx pins */
    IfxPort_PadDriver  outputDriver;        /**< \brief Output pad driver of ccx and coutx pins *//* FIXME use generic type (No specific tricore AURIX type ) */
    Ifx_Priority              isrPriority;   /**< \brief Interrupt isrPriority of the timer interrupt, if 0 the interrupt is disable */
    IfxSrc_Tos                isrProvider;
    Ifx_ActiveState    ccxActiveState;      /**< \brief Top PWM active state */


    Ifx_GTM              *gtm;                                  /**< \brief Pointer to GTM module */
    Ifx_GTM_TIM          *tim;                                  /**< \brief Pointer to the TOM object */
    IfxGtm_Tim            timIndex;                             /**< \brief Enum for TOM objects */
    IfxGtm_Tim_Ch         captureChannel;

} Inputcapture_Config;

typedef struct
{
	Ifx_GTM 					*gtm;
	Inputcapture_Config     	base;      /**< \brief PWM HL standard interface configuration */
	IfxGtm_IrqMode       		irqModeTimer;
    IfxGtm_Tim                 	tim;       /**< \brief TOM unit used */
    const IfxGtm_Tim_TinMapP 	*tim_pointer;       /**< \brief Pointer to an array of size base.channelCount/2 containing the channels used. All channels used for ccx and coutx must be adjacent to the channel used for the timer, order is not important. */
    IfxGtm_Tim_Ch         		captureChannel;
} IfxGtm_Tim_capture_Config;

typedef struct
{
    struct
    {
        float32 gtmFreq;
        float32 gtmGclkFreq;
    }info;
    struct
    {
    	Inputcapture_Config timinputcapture;        /**< \brief Timer driver */
    }drivers;
    struct
    {
        uint32 slotOneMs;
    }isrCounter;
} App_GtmTimInput;





#endif /* 0_SRC_0_APPSW_APP_INC_TEST_ENCODER_H_ */
