/*******************************************************************************
 * File name: Road_test.c
 * Author: Seokwon Kim
 * Created date: 2016. 6. 10
 * Objective: source file for check vehicle location
 * ----------------------------- Revision history -----------------------------
 * version 0.1 - 2016.04.28
 *   == Initial version(by Seokwon)
 *******************************************************************************/

/*******************************************************************************
 * Include
 *******************************************************************************/
#include "Road_test.h"
#include "Camera_Data_Process.h"
#include "PWM.h"
/*******************************************************************************
 * Constant
 *******************************************************************************/

/*******************************************************************************
 * Define & MACRO
 *******************************************************************************/

/*******************************************************************************
 * Type Definition
 *******************************************************************************/

/*******************************************************************************
 * Prototypes of Local Functions
 *******************************************************************************/

/*******************************************************************************
 * Static Variable
 *******************************************************************************/

/*******************************************************************************
 * Exported Global Variables
 *******************************************************************************/

extern int Left_line;
extern int Right_line;

extern int condition_obs;
extern int Pure_Pursuit_state;
/*******************************************************************************
 * Exported Functions
 * Function name:Obstacle_avoidance
 * Description: algorithm for Obstacle avoidance
 *******************************************************************************/

void Road_test(void) {

	if (condition_obs == 2) {

		Pure_Pursuit_state = 0;

		Motor_PWM_Duty(45, 0);
/*
		while (Right_line > 60) {
			Servo_PWM_Duty(31250, -20);
		}

		while (1) {
			Servo_PWM_Duty(31250, -20);
			//if (Right_line >100)
			if (Right_line < 30||Right_line==120)
				break;
		}

		 while (1) {
		 Servo_PWM_Duty(31250, 7);
		 if (Right_line < 115 && Right_line >40)
		 break;
		 }

		 while (Right_line > 7) {
		 Servo_PWM_Duty(31250,20);
		 }*/

		   while (Right_line > 70) {
		      Servo_PWM_Duty(31250, -14);
		   }

		   while (1) {
		      Servo_PWM_Duty(31250, -11);
		      if (Right_line >100)
		         break;
		   }

		   while (1) {
		      Servo_PWM_Duty(31250, 8);
		      if (Right_line < 115)
		         break;
		   }
/*
		   while (Right_line > 90) {
		      Servo_PWM_Duty(31250, 8);
		   }
*/
		Pure_Pursuit_state = 1;

		condition_obs = 0;
	}
	Pure_Pursuit_state = 1;
}
