/*******************************************************************************
 * File name: Hill_detect.c
 * Author: Seokwon Kim
 * Created date: 2016. 6. 10
 * Objective: source file for detecting hill
 * ----------------------------- Revision history -----------------------------
 * version 0.1 - 2016.04.28
 *   == Initial version(by Seokwon)
 *******************************************************************************/

/*******************************************************************************
 * Include
 *******************************************************************************/
#include "Hill_detect.h"
#include "Infrared_Data_Process.h"
#include "Camera_Data_Process.h"
#include "PWM.h"
#include "bspconfig.h"
/*******************************************************************************
 * Constant
 *******************************************************************************/
int Hill_state = 0;

int Hill_position = 0;

int Hill_distance = 450;

int angle_state = 0;

/*******************************************************************************
 * Define & MACRO
 *******************************************************************************/

/*******************************************************************************
 * Type Definition
 *******************************************************************************/

/*******************************************************************************
 * Prototypes of Local Functions
 *******************************************************************************/

/*******************************************************************************
 * Static Variable
 *******************************************************************************/

/*******************************************************************************
 * Exported Global Variables
 *******************************************************************************/
extern int Infrared_use;
extern int Infrared_use_1;
extern int Left_line;
extern int Left_line_before2;
extern int Right_line;
extern int Right_line_before2;
extern int Pure_Pursuit_state;
extern int Track_Center_line;
extern long double Wheel_angle;
/*******************************************************************************
 * Exported Functions
 * Function name: Hill_detect.c
 * Description: algorithm for detecting hill
 *******************************************************************************/
void Hill_detect(void) {

	if (Infrared_use_1 > Hill_distance && Infrared_use < 50) {//450

		Pure_Pursuit_state = 0;        //turn off Pure Pursuit

		Hill_state = 1;					//turn off AEB, School_zone_detect

		Hill_position = 0;
	}
	P13_OUT.U = 0x0000000f;
	while (Hill_state == 1) {

		Motor_PWM_Duty(100, 0);

		switch (Hill_position) {

		case 0:
			P13_OUT.U = 0x00000000;
			if (Left_line != 7 && Right_line != 120) {
				if (Right_line - Right_line_before2 < 0) {			// �� ��ġ /���
					Servo_PWM_Duty(31250, 0); // ��¦ ��ȸ��
					angle_state = 0;
				} else if (0 <= Right_line - Right_line_before2) { // �� ��ġ \���
					Servo_PWM_Duty(31250, 0); // ��¦ ��ȸ��
					angle_state = 1;
				}
			} else if (Left_line == 7 && Right_line == 120) {
				Servo_PWM_Duty(31250, 0);
				angle_state = 1;
			} else if (Left_line == 7 && Right_line != 120) {
				if (Right_line - Right_line_before2 < 0) { // �� ��ġ /���
					Servo_PWM_Duty(31250, 0);
					angle_state = 0;
				} else if (0 <= Right_line - Right_line_before2) { // �� ��ġ \���
					Servo_PWM_Duty(31250, 0);
					angle_state = 1;
				}
			} else if (Left_line != 7 && Right_line == 120) {
				if (Left_line - Left_line_before2 < 0) { // �� ��ġ /���
					Servo_PWM_Duty(31250, 0);
					angle_state = 0;
				} else if (0 <= Left_line - Left_line_before2) { // �� ��ġ \���
					Servo_PWM_Duty(31250, 0);
					angle_state = 1;
				}
			}

			if(angle_state == 0){
				Track_Center_line = 8;
			}
			else if(angle_state == 1){
				Track_Center_line = 119;
			}

			Hill_position = 1;

			break;

		case 1:
			P13_OUT.U = 0x00000001;
			if (angle_state == 0) {
				Servo_PWM_Duty(31250, 0);
			} else if (angle_state == 1) {
				Servo_PWM_Duty(31250, 0);
			}
			if (Infrared_use_1 < 200)
				Hill_position = 2;
			break;

		case 2:
			P13_OUT.U = 0x00000002;
			if (angle_state == 0) {
				Servo_PWM_Duty(31250, -1);
			} else if (angle_state == 1) {
				Servo_PWM_Duty(31250, -1);
			}
			if (Infrared_use_1 > 100)
				Hill_position = 3;
			break;
		case 3:
			P13_OUT.U = 0x00000004;
			if (angle_state == 0) {
				Servo_PWM_Duty(31250, -2);
			} else if (angle_state == 1) {
				Servo_PWM_Duty(31250, -2);
			}
			if (Infrared_use >= 0 && Infrared_use_1 > 780)
				Hill_position = 4;
			break;

		case 4:
			P13_OUT.U = 0x00000008;
			if (angle_state == 0) {
				Servo_PWM_Duty(31250, -2);
			} else if (angle_state == 1) {
				Servo_PWM_Duty(31250, -2);
			}
			if (Infrared_use_1 < Hill_distance) {
				Pure_Pursuit_state = 1;

				Hill_state = 0;

				Hill_position = 5;

			}
			break;
		}

		if (Hill_state == 0) {
			break;
		}

	}

}
