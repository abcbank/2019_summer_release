
/*******************************************************************************
 * File name: .c
 * Author: Seokwon Kim
 * Created date: 2016. 6. 10
 * Objective: source file for
 * ----------------------------- Revision history -----------------------------
 * version 0.1 - 2016.04.28
 *   == Initial version(by Seokwon)
 *******************************************************************************/

/*******************************************************************************
 * Include
 *******************************************************************************/
#include "PID_control.h"
#include "bspconfig.h"
#include "PWM.h"

/*******************************************************************************
 * Constant
 *******************************************************************************/

long double error_prior = 0;
long double integral = 0;
long double error;
long double derivative;
long double Motor_duty;

long double K_p = 4;//400;	//25	//Gain for proportional
long double K_i = 0.0006;//70;	//60	//Gain for integration
long double K_d = 0.004;//0.5;	//6.7	//Gain for derivative
//long double K_p = 60;		//Gain for proportional
//long double K_i = 80;		//Gain for integration
//long double K_d = 10;		//Gain for derivative
//long double K_p = 25;		//Gain for proportional
//long double K_i = 60;		//Gain for integration
//long double K_d = 6.7;		//Gain for derivative
//long double K_p = 0.013319541272;
//long double K_i = 8.979694181790;
//long double K_d = 5;

/*******************************************************************************
 * Define & MACRO
 *******************************************************************************/

/*******************************************************************************
 * Type Definition
 *******************************************************************************/

/*******************************************************************************
 * Prototypes of Local Functions
 *******************************************************************************/

/*******************************************************************************
 * Static Variable
 *******************************************************************************/

/*******************************************************************************
 * Exported Global Variables
 *******************************************************************************/
extern long double Car_rpm_use;
/*******************************************************************************
 * Exported Functions
 * Function name: PID_control
 * Description: PID_Control for AEB
 *******************************************************************************/

void PID_control(long double Desired_rpm){
	P13_OUT.U = 0x00000000;
	error = Desired_rpm - Car_rpm_use;

	integral = integral + (error * 3);

	derivative = (error - error_prior) / 3;

	Motor_duty = K_p * error + K_i * integral + K_d * derivative;

	error_prior = error;

	if(Motor_duty >= 0){
		Motor_PWM_Duty(Motor_duty, 0);
	}
	else if(Motor_duty < -169){
		Motor_duty = -169;
		Motor_PWM_Duty(0, -Motor_duty);
	}
	else if(Motor_duty < 0){
		Motor_PWM_Duty(0, -Motor_duty);
	}

	if(Car_rpm_use < 100){
		Motor_PWM_Duty(0, 0);
	}

}

/*******************************************************************************
 * Local Functions
 * Function name:
 * Description:
 *******************************************************************************/



