
/*******************************************************************************
 * File name: PWM.c
 * Author: Seokwon Kim
 * Created date: 2016. 6. 10
 * Objective: source file for PWM
 * ----------------------------- Revision history -----------------------------
 * version 0.1 - 2016.04.28
 *   == Initial version(by Seokwon)
 *******************************************************************************/

/*******************************************************************************
 * Include
 *******************************************************************************/
#include "bspconfig.h"
#include "PWM.h"


/*******************************************************************************
 * Constant
 *******************************************************************************/



/*******************************************************************************
 * Define & MACRO
 *******************************************************************************/

/*******************************************************************************
 * Type Definition
 *******************************************************************************/

/*******************************************************************************
 * Prototypes of Local Functions
 *******************************************************************************/

/*******************************************************************************
 * Static Variable
 *******************************************************************************/

/*******************************************************************************
 * Exported Global Variables
 *******************************************************************************/

/*******************************************************************************
 * Exported Functions
 * Function name: Setting_TOM
 * Description: setting for TOM
 *******************************************************************************/

void Setting_TOM(void) {

	P00_IOCR4.B.PC7 = 0b10001; //Choose Port00.7 as alt 1		tom1_6 CLK
	P00_IOCR8.B.PC9 = 0b10001; //Choose Port00.9 as alt 1		tom1_0	SI
	P00_IOCR12.B.PC12 = 0b10001;	//Choose Port00.12 as alt 1		tom0_3 Servo
	P33_IOCR0.B.PC3 = 0b10000;	//motor
	P33_IOCR4.B.PC4 = 0b10000;	//motor
	P33_IOCR4.B.PC5	= 0b10001;	//tom 0_1 motor
	P33_IOCR4.B.PC6	= 0b10001;	//tom 0_2 motor

	unlock_wdtcon(); 		//cpu �� Ǯ��

	GTM_CLC.B.DISR = 0;
		while (GTM_CLC.B.DISS == 1) {
		;
	}

	lock_wdtcon();

	//CMU Clock Enable Register, Enable clock source 0 and Enable Fixed Clock Generation
	GTM_CMU_FXCLK_CTRL.B.FXCLK_SEL = 0b0001;
	GTM_CMU_CLK_EN.B.EN_FXCLK = 0b10;
	GTM_CMU_CLK_EN.B.EN_CLK0 = 0b10;

	GTM_TOUTSEL1.B.SEL2 = 0b01; 	//Timer Output Select Register �޴���2407page. SI
	GTM_TOUTSEL1.B.SEL0 = 0b01; 	//Timer Output Select Register �޴���2407page. CLK
	GTM_TOUTSEL1.B.SEL5 = 0b00;		//servo
	GTM_TOUTSEL1.B.SEL11 = 0b00;	//motor P33.5
	GTM_TOUTSEL1.B.SEL12 = 0b00;	//motor P33.6

	GTM_TOM1_TGC0_GLB_CTRL.B.UPEN_CTRL6 = 0b10;											//CLK
	GTM_TOM1_TGC0_GLB_CTRL.B.UPEN_CTRL0 = 0b10;											//SI
	GTM_TOM0_TGC0_GLB_CTRL.B.UPEN_CTRL3 = 0b10;											//servo
	GTM_TOM0_TGC0_GLB_CTRL.B.UPEN_CTRL1 = 0b10;											//tom 0_1 motor
	GTM_TOM0_TGC0_GLB_CTRL.B.UPEN_CTRL2 = 0b10;											//tom 0_2 motor

	GTM_TOM1_TGC0_ENDIS_CTRL.B.ENDIS_CTRL6 = 0b10; // Enable							//CLK
	GTM_TOM1_TGC0_ENDIS_STAT.B.ENDIS_STAT6 = 0b10; // Enable							//CLK

	GTM_TOM1_TGC0_OUTEN_CTRL.B.OUTEN_CTRL6 = 0b10; // Enable Output						//CLK
	GTM_TOM1_TGC0_OUTEN_STAT.B.OUTEN_STAT6 = 0b10; // Enable Output						//CLK

	GTM_TOM1_TGC0_ENDIS_CTRL.B.ENDIS_CTRL0 = 0b10; // Enable							//SI
	GTM_TOM1_TGC0_ENDIS_STAT.B.ENDIS_STAT0 = 0b10; // Enable							//SI

	GTM_TOM1_TGC0_OUTEN_CTRL.B.OUTEN_CTRL0 = 0b10; // Enable Output						//SI
	GTM_TOM1_TGC0_OUTEN_STAT.B.OUTEN_STAT0 = 0b10; // Enable Output						//SI

	GTM_TOM0_TGC0_ENDIS_CTRL.B.ENDIS_CTRL3 = 0b10;										//servo
	GTM_TOM0_TGC0_ENDIS_STAT.B.ENDIS_STAT3 = 0b10;										//servo

	GTM_TOM0_TGC0_OUTEN_CTRL.B.OUTEN_CTRL3 = 0b10;										//servo
	GTM_TOM0_TGC0_OUTEN_STAT.B.OUTEN_STAT3 = 0b10;										//servo

	GTM_TOM0_TGC0_ENDIS_CTRL.B.ENDIS_CTRL1 = 0b10; // Enable							//tom 0_1 motor
	GTM_TOM0_TGC0_ENDIS_STAT.B.ENDIS_STAT1 = 0b10; // Enable

	GTM_TOM0_TGC0_OUTEN_CTRL.B.OUTEN_CTRL1 = 0b10; // Enable Output
	GTM_TOM0_TGC0_OUTEN_STAT.B.OUTEN_STAT1 = 0b10; // Enable Output

	GTM_TOM0_TGC0_ENDIS_CTRL.B.ENDIS_CTRL2 = 0b10; // Enable							//tom 0_2 motor
	GTM_TOM0_TGC0_ENDIS_STAT.B.ENDIS_STAT2 = 0b10; // Enable

	GTM_TOM0_TGC0_OUTEN_CTRL.B.OUTEN_CTRL2 = 0b10; // Enable Output
	GTM_TOM0_TGC0_OUTEN_STAT.B.OUTEN_STAT2 = 0b10; // Enable Output

	// TOMi TGC0 Force Update Control Register
	GTM_TOM1_TGC0_FUPD_CTRL.B.FUPD_CTRL6 = 0b10;										//CLK
	GTM_TOM1_TGC0_FUPD_CTRL.B.RSTCN0_CH6 = 0b10;										//CLK

	// TOMi TGC0 Force Update Control Register
	GTM_TOM1_TGC0_FUPD_CTRL.B.FUPD_CTRL0 = 0b10;										//SI
	GTM_TOM1_TGC0_FUPD_CTRL.B.RSTCN0_CH0 = 0b10;										//SI

	// TOMi TGC0 Force Update Control Register
	GTM_TOM0_TGC0_FUPD_CTRL.B.RSTCN0_CH3 = 0b10;										//servo
	GTM_TOM0_TGC0_FUPD_CTRL.B.FUPD_CTRL3 = 0b10;										//servo

	GTM_TOM0_TGC0_FUPD_CTRL.B.RSTCN0_CH1 = 0b10;										//tom 0_1 motor
	GTM_TOM0_TGC0_FUPD_CTRL.B.FUPD_CTRL1 = 0b10;

	GTM_TOM0_TGC0_FUPD_CTRL.B.RSTCN0_CH2 = 0b10;										//tom 0_2 motor
	GTM_TOM0_TGC0_FUPD_CTRL.B.FUPD_CTRL2 = 0b10;

	//TOM0 Channel x Control Register ,000B CMU_FXCLK(0) selected: clock selected by FXCLKSEL
	GTM_TOM1_CH6_CTRL.B.TRIGOUT = 1;													//CLK
	GTM_TOM1_CH6_CTRL.B.RST_CCU0 = 0;													//CLK
	GTM_TOM1_CH6_CTRL.B.CLK_SRC_SR = 0b001;												//CLK
	GTM_TOM1_CH6_CTRL.B.SL = 1;															//CLK

	GTM_TOM1_CH0_CTRL.B.TRIGOUT = 1;													//SI
	GTM_TOM1_CH0_CTRL.B.RST_CCU0 = 0;													//SI
	GTM_TOM1_CH0_CTRL.B.CLK_SRC_SR = 0b001;	//Decide FXCLK Number(divide 1, *2^4, 2^8, 2^12, 2^16) 2331P		//SI
	GTM_TOM1_CH0_CTRL.B.SL = 1;															//SI

	GTM_TOM0_CH3_CTRL.B.TRIGOUT = 1;													//servo
	GTM_TOM0_CH3_CTRL.B.RST_CCU0 = 0;													//servo
	GTM_TOM0_CH3_CTRL.B.CLK_SRC_SR = 0b001;												//servo 2^4
	GTM_TOM0_CH3_CTRL.B.SL = 1;															//servo

	GTM_TOM0_CH1_CTRL.B.TRIGOUT = 1;													//motor
	GTM_TOM0_CH1_CTRL.B.RST_CCU0 = 0;													//motor
	GTM_TOM0_CH1_CTRL.B.CLK_SRC_SR = 0b001;	//Decide FXCLK Number(divide 1, *2^4, 2^8, 2^12, 2^16) 2331P		//motor
	GTM_TOM0_CH1_CTRL.B.SL = 1;														//motor

	GTM_TOM0_CH2_CTRL.B.TRIGOUT = 1;													//motor
	GTM_TOM0_CH2_CTRL.B.RST_CCU0 = 0;													//motor
	GTM_TOM0_CH2_CTRL.B.CLK_SRC_SR = 0b001;	//Decide FXCLK Number(divide 1, *2^4, 2^8, 2^12, 2^16) 2331P		//motor
	GTM_TOM0_CH2_CTRL.B.SL = 1;														//motor

	GTM_TOM1_CH6_IRQ_MODE.B.IRQ_MODE = 0b10;											//CLK

	GTM_TOM1_CH0_IRQ_MODE.B.IRQ_MODE = 0b10;											//SI

	GTM_TOM1_CH6_IRQ_EN.B.CCU0TC_IRQ_EN = 1;											//CLK

	GTM_TOM1_CH0_IRQ_EN.B.CCU0TC_IRQ_EN = 1;											//SI

}
/*******************************************************************************
 * Exported Functions
 * Function name: Camera_PWM_Duty
 * Description: setting for Camera PWM
 *******************************************************************************/
void Camera_PWM_Duty(int CLK0,int CLK1,int SI0,int SI1) {

	GTM_TOM1_CH6_SR0.U = CLK0; //TOM0 Channel x CCU0 Compare Register   1c			30	4e

	GTM_TOM1_CH6_SR1.U = CLK1;//TOM CCU1 compare register

	GTM_TOM1_CH0_SR0.U = SI0;//TOM1 Channel 0 CCU0 Compare Register
	//9858
	GTM_TOM1_CH0_SR1.U = SI1;//TOM CCU1 compare register *************************must be decided by experiment
	//10e
}
/*******************************************************************************
 * Exported Functions
 * Function name: Servo_PWM_Duty
 * Description: setting servo PWM Duty
 *******************************************************************************/
void Servo_PWM_Duty(int servo0, long double servo_angle){		//�¿�� 25����

	GTM_TOM0_CH3_SR0.U = servo0;//31250
//2332.5       + left
	GTM_TOM0_CH3_SR1.U = 2376.5 + servo_angle * 25; // ���ͳݻ󿡼� ���´�� 1���� 10 usec  //2812.5		2652.5
}//2295
/*******************************************************************************
 * Exported Functions
 * Function name: Motor_PWM_Duty
 * Description: setting Motor_PWM
 *******************************************************************************/
void Motor_PWM_Duty(long double motor0, long double motor1){

	P33_OUT.B.P3 = 1;
	P33_OUT.B.P4 = 1;
	//P33_OUT.B.P6 = 0;
	GTM_TOM0_CH1_SR0.U = 300;//1				0

	GTM_TOM0_CH1_SR1.U = motor0;

	GTM_TOM0_CH2_SR0.U = 300;//0 �� ��� ������		1 �ϰ�� ������

	GTM_TOM0_CH2_SR1.U = motor1;
}
/*******************************************************************************
 * Local Functions
 * Function name:
 * Description:
 *******************************************************************************/

