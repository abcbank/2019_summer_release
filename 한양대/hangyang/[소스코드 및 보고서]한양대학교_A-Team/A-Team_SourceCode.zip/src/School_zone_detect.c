/*******************************************************************************
 * File name: School_zone_detect.c
 * Author: Seokwon Kim
 * Created date: 2016. 4. 28
 * Objective: source file for School_zone_detect
 * ----------------------------- Revision history -----------------------------
 * version 0.1 - 2016.04.28
 *   == Initial version(by Seokwon)
 *******************************************************************************/

/*******************************************************************************
 * Include
 *******************************************************************************/
#include "School_zone_detect.h"
#include "Camera_Data_Process.h"
#include "Infrared_Data_Process.h"
#include "Obstacle_avoidance.h"
#include "bspconfig.h"

/*******************************************************************************
 * Constant
 *******************************************************************************/

/*******************************************************************************
 * Define & MACRO
 *******************************************************************************/

/*******************************************************************************
 * Type Definition
 *******************************************************************************/

/*******************************************************************************
 * Prototypes of Local Functions
 *******************************************************************************/

/*******************************************************************************
 * Static Variable
 *******************************************************************************/

/*******************************************************************************
 * Exported Global Variables
 *******************************************************************************/
extern int Camera_median[128];
extern int Camera_median_before_3[128];
extern int Camera_median_before_4[128];
extern int Infrared_use;
extern int Left_line;
extern int Right_line;
extern int Left_line_before2;
extern int Right_line_before2;
extern int condition_obs;

int count_School_zone_state = 0;
int Standard = 1000;

int avg_median = 0;
int avg_median_before_3 = 0;

int standard_state = 0;
/*******************************************************************************
 * Exported Functions
 * Function name: School_zone_detect
 * Description: detecting School zone
 *******************************************************************************/

void School_zone_detect(void) {

	int flag = 0;
	int before_state = 0;
	int White_value = 0;
	int White_number = 0;
	int sum_white_value = 0;
	int Black_value = 0;
	int sum_median = 0;
	int sum_median_before_3 = 0;
	//int avg_median = 0;
	//int avg_median_before_3 = 0;
	int Line_start = 30;
	int Line_end = 90;
	int Line_number = 60;
	int Percent_test = 0.35;

	if (standard_state == 1) {
		if (Infrared_use < 400 && condition_obs != 1 && condition_obs != 3) {

			if (Left_line_before2 == 7 && Right_line_before2 < 80) {  //��ȸ��
				Line_start = 27;
				Line_end = 57;
				Line_number = 30;
				Percent_test = 0.18;
			} else if (Left_line_before2 > 47 && Right_line_before2 == 120) { // ��ȸ��
				Line_start = 70;
				Line_end = 100;
				Line_number = 30;
				Percent_test = 0.18;
			} else {
				Line_start = 30;
				Line_end = 90;
				Line_number = 60;
				Percent_test = 0.25;
			}

			sum_median = 0;
			sum_median_before_3 = 0;

			for (flag = Line_start; flag < Line_end; flag++) {
				sum_median = sum_median + Camera_median[flag];
				sum_median_before_3 = sum_median_before_3
						+ Camera_median_before_3[flag];
			}

			avg_median = sum_median / Line_number;
			avg_median_before_3 = sum_median_before_3 / Line_number;

			switch (count_School_zone_state) {

			case 0:  //before3�� �����������ε� ���簪�� before3���� ����̸� count=1 -> ������ ����

				if (avg_median_before_3 < Standard) {
					if (avg_median > Standard) {
						for (flag = Line_start; flag < Line_end; flag++) {
							if (Camera_median[flag] > Standard
									&& Camera_median_before_3[flag]
											< Standard) {
								before_state++;
							}
						}
						if (before_state > Line_number * Percent_test) {
							count_School_zone_state = 1;
						}
					}
				}

				break;

			case 1:         //������ ���¿��� ������ ���� ������ count=2 ->������ Ż��

				for (flag = Line_start; flag < Line_end; flag++) {
					if (Camera_median[flag] < Standard
							&& Camera_median_before_3[flag] > Standard) {

						before_state++;
					}
				}
				if (before_state > Line_number * Percent_test) {
					if (avg_median_before_3 > Standard && avg_median < Standard)
						count_School_zone_state = 2;
				}

				break;

			case 2:

				for (flag = 30; flag < 90; flag++) {
					if (Camera_median_before_4[flag] > Standard
							&& Camera_median[flag] > Standard) {
						before_state++;
					}
				}
				if (before_state > 55) {
					count_School_zone_state = 3;
				}
				break;

			default:
				break;
			}
		}

	}

	if (Left_line != 7 && Right_line != 120) {

		sum_white_value = 0;
		White_number = 0;

		Black_value = (Camera_median[Left_line] + Camera_median[Right_line])
				/ 2;

		for (flag = Left_line + 20; flag < Right_line - 20; flag++) {
			sum_white_value = sum_white_value + Camera_median[flag];
			White_number++;
		}

		White_value = sum_white_value / White_number;
		Standard = ((Black_value + White_value) / 2) * 0.75;

		standard_state = 1;
	}
}

/*******************************************************************************
 * Local Functions
 * Function name:
 * Description:
 *******************************************************************************/
