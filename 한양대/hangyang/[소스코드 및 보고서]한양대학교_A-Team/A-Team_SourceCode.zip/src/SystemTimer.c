/*
 * SYSTEMTIMER.c
 *
 *  Created on: 2016. 4. 28.
 *      Author: USER
 */
/*******************************************************************************
 * File name: SystemTimer.c
 * Author: Seokwon Kim
 * Created date: 2016. 4. 28
 * Objective: source file for LED Blinking
 * ----------------------------- Revision history -----------------------------
 * version 0.1 - 2016.04.28
 *   == Initial version(by Seokwon)
 *******************************************************************************/

/*******************************************************************************
 * Include
 *******************************************************************************/
#include "bspconfig.h"
#include "interrupts.h"
#include "Camera_Data_Process.h"
#include "School_zone_detect.h"
#include "Scheduler.h"
#include "Infrared_Data_Process.h"
#include "Pure_Pursuit.h"

/*******************************************************************************
 * Constant
 *******************************************************************************/

int Camera_input[128] = { 0, };

long double Car_rpm_count = 0;
long double Car_rpm_count_1 = 0;

int trash = 0;

int Pixel_Data;

int count_Infrared = 0;

//for Camera_value processing
int count = 0;		//for saving Camera_input[128]

int Pure_Pursuit_state = 1;

int check_school_zone = 0;

extern int Hill_state;

int check_Hill_state = 0;

/*******************************************************************************
 * Define & MACRO
 *******************************************************************************/

/*******************************************************************************
 * Type Definition
 *******************************************************************************/

/*******************************************************************************
 * Prototypes of Local Functions
 *******************************************************************************/

void Count_Reset(int trash);

void Infrared_Camera_Data(int trash);

void rpm_1(int trash);
void rpm_2(int trash);

void BaseTick(uint32 nPeriodValue);


//for servo angle

/*******************************************************************************
 * Static Variable
 *******************************************************************************/

/*******************************************************************************
 * Exported Global Variables
 *******************************************************************************/

/*******************************************************************************
 * Exported Functions
 * Function name:
 * Description: function for initializing port output for LED
 *******************************************************************************/

void SysTimer_Init(void) {

	/* Value for periodic event*/
	uint32 u32_ComparValue = 10000;

	/*InterruptInitalize*/
	InterruptInit();

	/*Registration of interrupt handler )*/

	InterruptInstall(SRC_ID_GTMTOM13, Infrared_Camera_Data, 2, 0);

	InterruptInstall(SRC_ID_GTMTOM10, Count_Reset, 1, 0);

	InterruptInstall(SRC_ID_GTMTIM00, rpm_1, 3, 0);

	InterruptInstall(SRC_ID_GTMTIM07, rpm_2, 4, 0);

	InterruptInstall(SRC_ID_STM0SR0, BaseTick, 5, u32_ComparValue);


	/*System Timer Module Configuration */

	STM0_ISCR.B.CMP0IRR = 0x1;

	STM0_CMCON.B.MSIZE0 = 0b11111;
	STM0_CMCON.B.MSTART0 = 0b00000;

	STM0_CMP0.U = STM0_TIM0.B.STM31_0 + u32_ComparValue;

	STM0_ICR.B.CMP0EN = 1;

}

/*******************************************************************************
 * Local Functions
 * Function name: Infrared_Camera_Data
 * Description: save the Camera array and Infrared array
 *******************************************************************************/

void Infrared_Camera_Data(int trash) {

	Pixel_Data = VADC_G1_RES0.B.RESULT;

	if (count == 128)
		count = 127;

	Camera_input[count] = Pixel_Data;

	count++;

	if(count == 14){
		count_Infrared = 0;
	}
	else if(count == 28){
		count_Infrared = 1;
	}
	else if(count == 42){
		count_Infrared = 2;
	}
	else if(count == 56){
		count_Infrared = 3;
	}
	else if(count == 70){
		count_Infrared = 4;
	}
	else if(count == 84){
		count_Infrared = 5;
	}
	else if(count == 98){
		count_Infrared = 6;
	}
	else if(count == 112){
		count_Infrared = 7;
	}
	else if(count == 126){
		count_Infrared = 8;
	}

	if(count_Infrared < 9 && (count == 14 || count == 28 || count == 42 || count == 56 || count == 70 || count == 84 || count == 98 || count == 112 || count == 126)){

		Infrared_Data_Process();

		if(count_Infrared == 8){

			count_Infrared++;
		}
	}
	else if(count_Infrared == 9){

	}

}
/*******************************************************************************
 * Local Functions
 * Function name: Count_Reset
 * Description: Reset value about count and Camera_save
 *******************************************************************************/
void Count_Reset(int trash) {//      ī�޶� ���� ���� �� 112
	check_school_zone++;
	check_Hill_state++;
	count = 0;
	Camera_Data_Process();

	if(10 < check_school_zone && Hill_state == 0){

		School_zone_detect();

	}
	if(Pure_Pursuit_state == 1){

		Pure_Pursuit();
	}

	if(check_school_zone == 12){
		check_school_zone = 11;
	}
	if(100 < check_Hill_state){
		check_Hill_state = 101;
	}

}
/*******************************************************************************
 * Local Functions
 * Function name: rpm_1
 * Description: check the car speed
 *******************************************************************************/
void rpm_1(int trash) {

	Car_rpm_count = Car_rpm_count + 1;

	//TIM_result = GTM_TIM0_CH0_GPR1.B.GPR1;

	//Car_rpm = 200000000 / (50 * TIM_result * 8 * 16) * 39 / 60;
}
/*******************************************************************************
 * Local Functions
 * Function name: rpm_2
 * Description: check the car speed
 *******************************************************************************/
void rpm_2(int trash) {

	Car_rpm_count_1 = Car_rpm_count_1 + 1;

	//TIM_result_1 = GTM_TIM0_CH7_GPR1.B.GPR1;

	//Car_rpm = (-1) * 200000000 / (50 * TIM_result_1 * 8 * 16) * 39 / 60;
}

void BaseTick(uint32 nPeriodValue) {
	STM0_CMP0.U = STM0_CMP0.U + nPeriodValue;
	Scheduler();
}
