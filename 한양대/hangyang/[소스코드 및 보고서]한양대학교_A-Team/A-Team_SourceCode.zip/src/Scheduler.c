/*******************************************************************************
* File name: SystemTimer.c
* Author: Seokwon Kim
* Created date: 2016. 4. 28
* Objective: source file for LED Blinking
* ----------------------------- Revision history -----------------------------
* version 0.1 - 2016.04.28
*   == Initial version(by Seokwon)
*******************************************************************************/

/*******************************************************************************
* Include
*******************************************************************************/
#include "Scheduler.h"

/*******************************************************************************
* Constant
*******************************************************************************/


/*******************************************************************************
* Define & MACRO
*******************************************************************************/


/*******************************************************************************
* Type Definition
*******************************************************************************/


/*******************************************************************************
* Prototypes of Local Functions
*******************************************************************************/



/*******************************************************************************
* Static Variable
*******************************************************************************/
static uint16 u16_BaseCounter = 0;


static bool b_1msSchedule=FALSE;
static bool b_3msSchedule=FALSE;
static bool b_5msSchedule=FALSE;
static bool b_10msSchedule=FALSE;
static bool b_20msSchedule=FALSE;
static bool b_50msSchedule=FALSE;
static bool b_100msSchedule=FALSE;
static bool b_1sSchedule=FALSE;



/*******************************************************************************
* Exported Global Variables
*******************************************************************************/


/*******************************************************************************
* Exported Functions
* Function name:

*******************************************************************************/
void Scheduler(void)
{
	if(u16_BaseCounter % 10 == 0) b_1msSchedule = TRUE;
	if(u16_BaseCounter % 30 == 0) b_3msSchedule = TRUE;
	if(u16_BaseCounter % 50 == 0) b_5msSchedule = TRUE;
	if(u16_BaseCounter % 100 == 0) b_10msSchedule = TRUE;
	if(u16_BaseCounter % 200 == 0) b_20msSchedule = TRUE;
	if(u16_BaseCounter % 500 == 0) b_50msSchedule = TRUE;
	if(u16_BaseCounter % 1000 == 0) b_100msSchedule = TRUE;
	if(u16_BaseCounter % 10000 == 0) b_1sSchedule = TRUE;



	u16_BaseCounter++;
	if (u16_BaseCounter>= 60000) u16_BaseCounter = 0 ;


}

bool Scheduler_1ms(void)
{
	if (b_1msSchedule)
	{
		b_1msSchedule = FALSE;

		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

bool Scheduler_3ms(void)
{
	if (b_3msSchedule)
	{
		b_3msSchedule = FALSE;

		return TRUE;
	}
	else
	{
		return FALSE;
	}
}


bool Scheduler_5ms(void)
{
	if (b_5msSchedule)
	{
		b_5msSchedule = FALSE;

		return TRUE;
	}
	else
	{
		return FALSE;
	}
}


bool Scheduler_10ms(void)
{
	if (b_10msSchedule)
	{
		b_10msSchedule = FALSE;

		return TRUE;
	}
	else
	{
		return FALSE;
	}
}




bool Scheduler_20ms(void)
{
	if (b_20msSchedule)
	{
		b_20msSchedule = FALSE;

		return TRUE;
	}
	else
	{
		return FALSE;
	}
}



bool Scheduler_50ms(void)
{
	if (b_50msSchedule)
	{
		b_50msSchedule = FALSE;

		return TRUE;
	}
	else
	{
		return FALSE;
	}
}






bool Scheduler_100ms(void)
{
	if (b_100msSchedule)
	{
		b_100msSchedule = FALSE;

		return TRUE;
	}
	else
	{
		return FALSE;
	}
}




bool Scheduler_1s(void)
{
	if (b_1sSchedule)
	{
		b_1sSchedule = FALSE;

		return TRUE;
	}
	else
	{
		return FALSE;
	}
}
/*******************************************************************************
* Exported Functions
* Function name:
* Description: function for turning on LEDs
*******************************************************************************/

/*******************************************************************************
* Exported Functions
* Function name:
* Description: function for turning off LEDs
*******************************************************************************/

/*******************************************************************************
* Exported Functions
* Function name:
* Description:
*******************************************************************************/


/*******************************************************************************
* Local Functions
* Function name:
* Description:
*******************************************************************************/

