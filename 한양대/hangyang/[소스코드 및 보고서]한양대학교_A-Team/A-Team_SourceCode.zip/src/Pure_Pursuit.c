

/*******************************************************************************
 * File name: Pure_Pursuit.c
 * Author: Seokwon Kim
 * Created date: 2016. 6. 10
 * Objective: source file for Pure Pursuit
 * ----------------------------- Revision history -----------------------------
 * version 0.1 - 2016.04.28
 *   == Initial version(by Seokwon)
 *******************************************************************************/

/*******************************************************************************
 * Include
 *******************************************************************************/
#include <math.h>
#include "Pure_Pursuit.h"
#include "PWM.h"
#include "Wheel_angle_check.h"
#include "Camera_Data_Process.h"
/*******************************************************************************
 * Constant
 *******************************************************************************/

long double Distance_pixel = 5;
long double Direction_point_X = 622;	//ī�޶� �д� �� �������
long double Direction_point_Y;			//ī�޶� �д� �� �������
long double R_track;					//ȸ�� �ݰ�
long double Wheel_angle = 0;				//���Ⱒ

long double Distance_wheel = 256;		//���� ����� �Ÿ�
long double Parameter;					//�߰�����
long double Wheel_gain = 0.8;
int Current_state = 0;
/*******************************************************************************
 * Define & MACRO
 *******************************************************************************/

/*******************************************************************************
 * Type Definition
 *******************************************************************************/

/*******************************************************************************
 * Prototypes of Local Functions
 *******************************************************************************/

/*******************************************************************************
 * Static Variable
 *******************************************************************************/

/*******************************************************************************
 * Exported Global Variables
 *******************************************************************************/
extern int Left_line;
extern int Right_line;
/*******************************************************************************
 * Exported Functions
 * Function name: Pure_Pursuit
 * Description: calculate to Pure Pursuit
 *******************************************************************************/

void Pure_Pursuit(void){
//16 112
	if(Right_line == 120 && Left_line == 7){

	}
	else if (Right_line == 120){

		Direction_point_Y = (48 - (63.5 - Left_line)) * Distance_pixel;//�������� ���� �� �Է��� ��ȸ��
		//Left Line�� �ν�
	}
	else if (Left_line == 7){

		Direction_point_Y = ((Right_line - 63.5) - 48) * Distance_pixel;//�������� ��� ���� ��ȸ��
		//Right Line�� �ν�
	}

	else if (Right_line != 120 && Left_line != 7){

	//	if(Left_line > 14.5){

		//	Direction_point_Y = ((Right_line - 63.5) - 48) * Distance_pixel;
	//	}
	//	else if(Right_line < 111.5){

			Direction_point_Y = (48 - (63.5 - Left_line)) * Distance_pixel;
		//}
		//else{

		//	Direction_point_Y = ((Right_line - 63.5) - 48) * Distance_pixel;
		//}
	}

	R_track = (Direction_point_X * Direction_point_X + Direction_point_Y * Direction_point_Y) / (2 * Direction_point_Y);

	Parameter = Distance_wheel / R_track;

	Wheel_angle = Wheel_gain * atan(Parameter) * 180 / M_PI;

	if (Wheel_angle < 0){
		Wheel_angle = 1.24 * Wheel_angle;
//1.2
		if (Wheel_angle < -50){							//��ȸ��

			Wheel_angle = -50;
		}

	}
	else if (Wheel_angle > 0){
		Wheel_angle = 1 * Wheel_angle;					//��ȸ��
//1.35
		if (Wheel_angle > 50){

			Wheel_angle = 50;
		}

	}

	if (Direction_point_Y == 0){
		Wheel_angle = 0;
		}

	Wheel_angle_check();

	Servo_PWM_Duty(31250, -Wheel_angle);


}

/*******************************************************************************
 * Local Functions
 * Function name:
 * Description:
 *******************************************************************************/



