/*====================================================================
 * Project:  Board Support Package (BSP) examples
 * Function: empty main function
 *
 * Copyright HighTec EDV-Systeme GmbH 1982-2013
 *====================================================================*/
// Before the race, please you must check Camera CLK/SI and Kernel Threshold
#include <stdlib.h>
#include "bspconfig.h"
#include "interrupts.h"
#include "Scheduler.h"
#include "PLL.h"
#include "PWM.h"
#include "VADC.h"
#include "TIM_set.h"
#include "Pure_Pursuit.h"
#include "Car_rpm.h"
#include "AEB.h"
#include "Obstacle_avoidance.h"
#include "Road_test.h"
#include "School_zone_detect.h"
#include "Hill_detect.h"


extern int count_School_zone_state;
extern int Pure_Pursuit_state;
extern int Hill_state;
extern int check_Hill_state;

int main(void) {

	SysTimer_Init();

	PLL_200();

	Camera_VADC_set();

	Setting_TOM();

	Tim_set();

	Camera_PWM_Duty(100, 50, 15000, 200);//clk period 50us si period 10ms

	Servo_PWM_Duty(31250, 0);

	Pure_Pursuit_state = 1;

	count_School_zone_state = 0;

	while (1) {

		P13_IOCR0.U = 0x80808080;


			if (count_School_zone_state == 1) {

				Motor_PWM_Duty(45, 0);

				Obstacle_avoidance();
			} else {

				Road_test();
				if(100 <= check_Hill_state){

					Hill_detect();
				}

				if (Scheduler_3ms()) {

					Car_rpm_value();

					if(Hill_state == 0){

						AEB();
					}
				}
			}

	}
	return EXIT_SUCCESS;
}
