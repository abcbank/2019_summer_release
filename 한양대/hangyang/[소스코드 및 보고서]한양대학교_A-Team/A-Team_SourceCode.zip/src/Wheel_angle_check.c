/*******************************************************************************
 * File name: Wheel_angle_check.c
 * Author: Seokwon Kim
 * Created date: 2016. 4. 28
 * Objective: source file for checking Wheel angle
 * ----------------------------- Revision history -----------------------------
 * version 0.1 - 2016.04.28
 *   == Initial version(by Seokwon)
 *******************************************************************************/

/*******************************************************************************
 * Include
 *******************************************************************************/
#include "bspconfig.h"
#include "Wheel_angle_check.h"
/****************************************************
#include "PWM.h"
#include "Camera_Data_Process.h"***************************
 /*******************************************************************************
 * Constant
 *******************************************************************************/

/*******************************************************************************
 * Define & MACRO
 *******************************************************************************/

/*******************************************************************************
 * Type Definition
 *******************************************************************************/

/*******************************************************************************
 * Prototypes of Local Functions
 *******************************************************************************/

/*******************************************************************************
 * Static Variable
 *******************************************************************************/

/*******************************************************************************
 * Exported Global Variables
 *******************************************************************************/
//extern long double Wheel_gain;
extern long double Wheel_angle;

long double Kd = 0.85;
//long double Kd_0 =5.8;
//long double Kp = 0.4;
//int p_e = 0;
//int d_e = 0;
extern int Left_line;
extern int Right_line;
int desired_Right_line = 110;
int desired_Left_line = 15;
extern int Left_line_before2;
extern int Right_line_before2;



/*******************************************************************************
 * Exported Functions
 * Function name: Wheel_angle_check
 * Description:	checking Wheel angle
 *******************************************************************************/
void Wheel_angle_check(void) {
	if (Left_line <= 15) { //turn left

	//p_e = Right_line - desired_Right_line;   //-
	//d_e = Right_line - Right_line_before2;    //-
		//if(Right_line > Right_line_before2)
			Wheel_angle = Wheel_angle + 1.054 * (Right_line - Right_line_before2);
		//else
		//	Wheel_angle=Wheel_angle +  Kd_0 * (Right_line - Right_line_before2);

	} else if (Left_line > 15) {            //turn right


		//else
			//Wheel_angle = Wheel_angle + Kd_0 * (Left_line - Left_line_before2);

			if( 20 < Left_line){
				// if(Left_line < Left_line_before2){

					 Wheel_angle = 1.42*Wheel_angle + Kd * (Left_line - Left_line_before2);
				// }
			}
			else{
				//if(Left_line < Left_line_before2){

					Wheel_angle = Wheel_angle + Kd * (Left_line - Left_line_before2);
				//}

			}
	//p_e = Left_line - desired_Left_line;    //+
	//d_e = Left_line - Left_line_before2;     //+

	}

	//Wheel_angle=Wheel_angle + Kp*p_e - Kd*d_e;
	if(25 <= Wheel_angle){

		Wheel_angle=25;
	}
	else if(Wheel_angle <= -25){

		Wheel_angle = -25;
	}
}

/*******************************************************************************
 * Local Functions
 * Function name:
 * Description:
 *******************************************************************************/
