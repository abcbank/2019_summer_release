
/*******************************************************************************
 * File name: Camera_Data_Process.c
 * Author: Seokwon Kim
 * Created date: 2016. 6. 10
 * Objective: source file for Camera data process
 * ----------------------------- Revision history -----------------------------
 * version 0.1 - 2016.04.28
 *   == Initial version(by Seokwon)
 *******************************************************************************/

/*******************************************************************************
 * Include
 *******************************************************************************/
#include "Camera_Data_Process.h"
/*******************************************************************************
 * Constant
 *******************************************************************************/
int Camera_median[128] = { 0, };
int Camera_median_1[128] = { 0, };
int Camera_median_before[128] = { 0, };
int Camera_median_before_1[128] = { 0, };
int Camera_median_before_2[128] = { 0, };
int Camera_median_before_3[128] = { 0, };
int Camera_median_before_4[128] = { 0, };
int Camera_kernel[128] = { 0, };
int Camera_use[128] = { 0, };

//for detecting line
int k = 0;			//for comparing kernel value
int Left_line_compare;
int Right_line_compare;
int Left_line = 7;
int Right_line = 120;
int Track_Center_line = 64;

int Left_line_before = 7;
int Right_line_before = 120;
int Left_line_before2 = 7;
int Right_line_before2=120;
int Left_line_before3 = 7;
int Right_line_before3=120;
int Left_line_before4 = 7;
int Right_line_before4=120;

int i = 0;			//for saving Camera_kernel[128]

int j = 0;			//for saving Camera_use[128]

int q = 0;

int tem = 0;

int Line_threshold_Left = 4000;		//Line threshold
int Line_threshold_Right = 4000;		//Line threshold
/*******************************************************************************
 * Define & MACRO
 *******************************************************************************/

/*******************************************************************************
 * Type Definition
 *******************************************************************************/

/*******************************************************************************
 * Prototypes of Local Functions
 *******************************************************************************/

/*******************************************************************************
 * Static Variable
 *******************************************************************************/

/*******************************************************************************
 * Exported Global Variables
 *******************************************************************************/
extern int Camera_input[128];

/*******************************************************************************
 * Exported Functions
 * Function name: Camera_Data_Process
 * Description: calculating camera data
 *******************************************************************************/
void Camera_Data_Process(void){

	for(i = 0 ; i < 128 ; i++){
			Camera_median_before_4[i] = Camera_median_before_3[i];
	}
	for(i = 0 ; i < 128 ; i++){
			Camera_median_before_3[i] = Camera_median_before_2[i];
	}
	for(i = 0 ; i < 128 ; i++){
			Camera_median_before_2[i] = Camera_median_before_1[i];
	}
	for(i = 0 ; i < 128 ; i++){
			Camera_median_before_1[i] = Camera_median_before[i];
	}
	for(i = 0 ; i < 128 ; i++){
			Camera_median_before[i] = Camera_median[i];
	}

	for( i = 2 ; i < 126 ; i++){

		Camera_median_1[i-2] = Camera_input[i-2];
		Camera_median_1[i-1] = Camera_input[i-1];
		Camera_median_1[i] = Camera_input[i];
		Camera_median_1[i+1] = Camera_input[i+1];
		Camera_median_1[i+2] = Camera_input[i+2];

		for(j = i - 2 ; j < i + 2 ; j++){

			 for( q = i - 1 ; q < i + 3 ; q++){

				 if(Camera_median_1[j] > Camera_median_1[q]){

					 tem = Camera_median_1[j];

					 Camera_median_1[j] = Camera_median_1[q];

					 Camera_median_1[q] = tem;
				 }
			 }
		 }

		Camera_median[i] = Camera_median_1[i];
	}


	for (i = 0; i < 128; i++){

		Camera_kernel[i] = 4095 - Camera_median[i];
	}



	/* For calculating kernel matrix*/
	for (j = 6; j < 122; j++){
		Camera_use[j] = Camera_kernel[j - 6] * (-5) + Camera_kernel[j - 5] * (-5) +  Camera_kernel[j - 4] * (-5) +  Camera_kernel[j - 3] * (-5)
						+ Camera_kernel[j - 2] * 5 + Camera_kernel[j - 1] * 10 + Camera_kernel[j] * 10  + Camera_kernel[j + 1] * 10 + Camera_kernel[j + 2] * 5
						+ Camera_kernel[j + 3] * (-5) + Camera_kernel[j + 4] * (-5) + Camera_kernel[j + 5] * (-5) + Camera_kernel[j + 6] * (-5);
	}

	Left_line_compare = Camera_use[7];
	Right_line_compare = Camera_use[Track_Center_line];

	for (k = 7; k < Track_Center_line; k++){

		if (Camera_use[k] >= Left_line_compare){
			Left_line_compare = Camera_use[k];
			Left_line = k;
		}

		if(Left_line < 7){
			Left_line = 7;
		}
		else if(Left_line > 115){
			;
		}
	}

	for (k = Track_Center_line; k < 121; k++){

		if (Camera_use[k] > Right_line_compare){
			Right_line_compare = Camera_use[k];
			Right_line = k;
		}

		if(Right_line > 120){
			Right_line = 120;
		}
		else if(Right_line < 17){
			;
		}
	}

	if (Left_line_compare < Line_threshold_Left){

		Left_line = 7;
	}
	if (Right_line_compare < Line_threshold_Right){

		Right_line = 120;
	}



	if (Right_line < 100) {

		Track_Center_line = 8;
		Left_line = 7;
	}
	else if (Left_line > 28) {

		Track_Center_line = 119;
		Right_line = 120;
	}
	else if (Right_line == 120 && Left_line == 7) {

	}
	else {

		Track_Center_line = 64;
	}

	Left_line_before4 = Left_line_before3;
	Right_line_before4 = Right_line_before3;
	Left_line_before3 = Left_line_before2;
	Right_line_before3 = Right_line_before2;
	Left_line_before2 = Left_line_before;
	Right_line_before2 = Right_line_before;
	Left_line_before = Left_line;
	Right_line_before = Right_line;


}
/*******************************************************************************
 * Local Functions
 * Function name:
 * Description:
 *******************************************************************************/






