/*
 * VADC.c
 *
 *  Created on: 2016. 6. 10.
 *      Author: USER
 */
/*******************************************************************************
 * File name: VADC.c
 * Author: Seokwon Kim
 * Created date: 2016. 4. 28
 * Objective: source file for VADC
 * ----------------------------- Revision history -----------------------------
 * version 0.1 - 2016.04.28
 *   == Initial version(by Seokwon)
 *******************************************************************************/

/*******************************************************************************
 * Include
 *******************************************************************************/
#include "bspconfig.h"
#include "VADC.h"
/*******************************************************************************
 * Constant
 *******************************************************************************/

/*******************************************************************************
 * Define & MACRO
 *******************************************************************************/

/*******************************************************************************
 * Type Definition
 *******************************************************************************/

/*******************************************************************************
 * Prototypes of Local Functions
 *******************************************************************************/

/*******************************************************************************
 * Static Variable
 *******************************************************************************/

/*******************************************************************************
 * Exported Global Variables
 *******************************************************************************/

/*******************************************************************************
 * Exported Functions
 * Function name: Camera_VADC_set
 * Description:	setting VADC
 *******************************************************************************/
							//AN1 ��� Mode switch			G0 CH1
void Camera_VADC_set(void)  //AN12 ��� P41.0 Camera		G1 Ch0
{							//AN10 ��� Infrared sensor    G0 ch10
	unlock_wdtcon(); 		//cpu unlock

	VADC_CLC.B.DISR = 0;	//�������� 2727 ����
	while(VADC_CLC.B.DISS ==1){
			;
		}

	lock_wdtcon();

	VADC_G1ARBCFG.B.ANONC = 0b11; 	/* Analog Converter Control Mode (setting normal operation mode) */
	VADC_G1ARBCFG.B.ARBM = 0b0;		/* Arbitration Mode(The arbiter runs permanently) */
	VADC_G0ARBCFG.B.ANONC = 0b11; 	/* Analog Converter Control Mode (setting normal operation mode) */
	VADC_G0ARBCFG.B.ARBM = 0b0;		/* Arbitration Mode(The arbiter runs permanently) */

	VADC_GLOBCFG.B.SUCAL = 1;		/* start-up calibration(initiate the start-up calibration phase) */
	VADC_GLOBCFG.B.DIVWC = 1;		/* write control(DIVA, DCMSB, DIVD, REFPC, LOSUP) */
	VADC_GLOBCFG.B.REFPC = 1;		/* Use V_REF for the conversion */
	VADC_GLOBCFG.B.LOSUP = 0;		/* Power Supply Voltage Select(5V or 3V) */
	VADC_GLOBCFG.B.DIVD = 0b00;		/* Divider Factor for the Arbiter Clock */
	VADC_GLOBCFG.B.DIVA = 0b00000;	/* Divider Factor for the Analog Internal Clock */

	VADC_G1ARBPR.B.ASEN1 = 1; 		/* Use Request Source 1(Channel Scan) */
	VADC_G0ARBPR.B.ASEN1 = 1; 		/* Use Request Source 1(Channel Scan) */


	VADC_G1CHCTR0.B.ICLSEL = 0b00;	/* Input class select(use group-specific class0*/								/*���� ���� ����� ���� */
	VADC_G1CHCTR0.B.REFSEL = 0;		/* Standard Input Request(Standard Reference Input V_REF) */
	VADC_G1CHCTR0.B.RESREG = 0b0000;/* Result Register (use G1_RES0) *///***************************************
	VADC_G1CHCTR0.B.RESPOS = 0;		/* store results left-aligned (page 2809)*/
	VADC_G0CHCTR10.B.ICLSEL = 0b00;	/* Input class select(use group-specific class0*/								/*���� ���� ����� ���� */
	VADC_G0CHCTR10.B.REFSEL = 0;		/* Standard Input Request(Standard Reference Input V_REF) */
	VADC_G0CHCTR10.B.RESREG = 0b1010;/* Result Register (use G0_RES10) *///***************************************
	VADC_G0CHCTR10.B.RESPOS = 0;		/* store results left-aligned (page 2809)*/
	VADC_G0CHCTR1.B.ICLSEL = 0b00;	/* Input class select(use group-specific class0*/								/*���� ���� ����� ���� */
	VADC_G0CHCTR1.B.REFSEL = 0;		/* Standard Input Request(Standard Reference Input V_REF) */
	VADC_G0CHCTR1.B.RESREG = 0b0001;/* Result Register (use G0_RES10) *///***************************************
	VADC_G0CHCTR1.B.RESPOS = 0;		/* store results left-aligned (page 2809)*/

	VADC_G1TRCTR.B.ITSEL = 0b01;	/* Internal Trigger Input Selection (scan request source) */
	VADC_G1TRCTR.B.SRDIS = 1;		/* Service Request Disable (No service request) */
	VADC_G0TRCTR.B.ITSEL = 0b01;	/* Internal Trigger Input Selection (scan request source) */
	VADC_G0TRCTR.B.SRDIS = 1;		/* Service Request Disable (No service request) */

	VADC_G1CHASS.B.ASSCH0 = 1;																						//���� ���� ����� ����
	VADC_G0CHASS.B.ASSCH10 = 1;																					//���� ���� ����� ����
	VADC_G0CHASS.B.ASSCH1 = 1;																					//���� ���� ����� ����

	VADC_G1RRASS.B.ASSRR0 = 1;
	VADC_G0RRASS.B.ASSRR10 = 1;
	VADC_G0RRASS.B.ASSRR1 = 1;

	VADC_G1ASMR.B.ENGT = 0b01;		/* Conversion requests are issued if at least one pending bit is set */
	VADC_G1ASMR.B.ENTR = 0;			/* External trigger disabled */
	VADC_G1ASMR.B.ENSI = 0;			/* No request source interrupt */
	VADC_G1ASMR.B.SCAN = 1;			/* Autoscan functionality enabled */
	VADC_G1ASMR.B.LDM = 0;			/* overwrite mode */
	VADC_G0ASMR.B.ENGT = 0b01;		/* Conversion requests are issued if at least one pending bit is set */
	VADC_G0ASMR.B.ENTR = 0;			/* External trigger disabled */
	VADC_G0ASMR.B.ENSI = 0;			/* No request source interrupt */
	VADC_G0ASMR.B.SCAN = 1;			/* Autoscan functionality enabled */
	VADC_G0ASMR.B.LDM = 0;			/* overwrite mode */

	VADC_G1ASCTRL.B.SRCRESREG = 0b0000;/*USE GxCHCTRy.RESREG to select a group result register */
	VADC_G1ASCTRL.B.XTWC = 1;		/* bitfield XTMODE, XTSEL can bo written */
	VADC_G1ASCTRL.B.GTWC = 1;		/* bitfield GTSEL can be written */
	VADC_G1ASCTRL.B.XTMODE = 0b10;
	VADC_G0ASCTRL.B.SRCRESREG = 0b0000;/*USE GxCHCTRy.RESREG to select a group result register */
	VADC_G0ASCTRL.B.XTWC = 1;		/* bitfield XTMODE, XTSEL can bo written */
	VADC_G0ASCTRL.B.GTWC = 1;		/* bitfield GTSEL can be written */
	VADC_G0ASCTRL.B.XTMODE = 0b10;

	VADC_G1ICLASS0.B.CMS = 0b000;	/* 12-bit resolution */
	VADC_G0ICLASS0.B.CMS = 0b000;	/* 12-bit resolution */


	VADC_G1ASSEL.U = 0x00000001;		/* It contains CHSEL bits. channel selection */									//��������� ����
	VADC_G0ASSEL.U = 0x00000402;		/* It contains CHSEL bits. channel selection */									//��������� ����

	VADC_G1ASPND.U = 0x00000001;		/* 0 is ignoring this channel, 1 is requesting conversion of this channel */
	VADC_G0ASPND.U = 0x00000402;		/* 0 is ignoring this channel, 1 is requesting conversion of this channel */

}
/*******************************************************************************
 * Local Functions
 * Function name:
 * Description:
 *******************************************************************************/

