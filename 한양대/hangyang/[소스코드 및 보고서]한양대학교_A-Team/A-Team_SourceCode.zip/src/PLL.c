
/*******************************************************************************
 * File name: PLL.c
 * Author: Seokwon Kim
 * Created date: 2016. 6. 10
 * Objective: source file for PLL frequency
 * ----------------------------- Revision history -----------------------------
 * version 0.1 - 2016.04.28
 *   == Initial version(by Seokwon)
 *******************************************************************************/

/*******************************************************************************
 * Include
 *******************************************************************************/
#include "bspconfig.h"
#include "PLL.h"
/*******************************************************************************
 * Constant
 *******************************************************************************/

/*******************************************************************************
 * Define & MACRO
 *******************************************************************************/

/*******************************************************************************
 * Type Definition
 *******************************************************************************/

/*******************************************************************************
 * Prototypes of Local Functions
 *******************************************************************************/

/*******************************************************************************
 * Static Variable
 *******************************************************************************/

/*******************************************************************************
 * Exported Global Variables
 *******************************************************************************/

/*******************************************************************************
 * Exported Functions
 * Function name:PLL_200
 * Description: PLL frequency 200MHz
 *******************************************************************************/

void PLL_200(void) {

	unlock_safety_wdtcon();
	while (SCU_CCUCON1.B.LCK != 0x0) {
		;
	}

	SCU_CCUCON1.B.GTMDIV = 0b1000;			// 8
	lock_safety_wdtcon();

	unlock_safety_wdtcon();

	SCU_OSCCON.B.MODE = 0b00;
	SCU_OSCCON.B.OSCVAL = 0b00111;

	SCU_CCUCON1.B.INSEL = 1;
	SCU_CCUCON1.B.UP = 1;

	lock_safety_wdtcon();

	while ((SCU_OSCCON.B.PLLLV != 0x1) || (SCU_OSCCON.B.PLLHV != 0x1)) {
		;
	}

	unlock_safety_wdtcon();

	while (SCU_CCUCON1.B.LCK != 0x0) {
		;
	}

	SCU_PLLCON0.B.VCOBYP = 0x1;

	SCU_PLLCON0.B.SETFINDIS = 1;
	SCU_PLLCON0.B.NDIV = 0x3B;

	SCU_PLLCON0.B.PDIV = 0x1;
	SCU_PLLCON0.B.PLLPWD = 0x1;

	//SCU_PLLCON1.B.K1DIV = 0x2;
	SCU_PLLCON1.B.K2DIV = 0x2;
	//SCU_PLLCON1.B.K3DIV = 0x5;
	SCU_PLLCON0.B.CLRFINDIS = 0x1;

	while (SCU_CCUCON0.B.LCK != 0x0) {
		;
	}

	SCU_CCUCON0.B.CLKSEL = 0x1;
	SCU_CCUCON0.B.UP = 0x1;
	lock_safety_wdtcon();

	while (SCU_PLLSTAT.B.VCOLOCK == 0x0) {
		;
	}

	unlock_safety_wdtcon();
	SCU_PLLCON0.B.VCOBYP = 0x0;
	lock_safety_wdtcon();

}

/*******************************************************************************
 * Local Functions
 * Function name:
 * Description:
 *******************************************************************************/
