
/*******************************************************************************
 * File name: Infrared_Data_Process.c
 * Author: Seokwon Kim
 * Created date: 2016. 6. 10
 * Objective: source file for Infrared_data_process
 * ----------------------------- Revision history -----------------------------
 * version 0.1 - 2016.04.28
 *   == Initial version(by Seokwon)
 *******************************************************************************/

/*******************************************************************************
 * Include
 *******************************************************************************/
#include "Infrared_Data_Process.h"
#include "bspconfig.h"
/*******************************************************************************
 * Constant
 *******************************************************************************/
int Infrared_input[9] = { 0, };
int Infrared_input_1[9] = { 0, };
int a = 0;
int b = 0;
int temp = 0;
int temp_1 = 0 ;

int Infrared_use = 0;
int Infrared_use_1 =0;
/*******************************************************************************
 * Define & MACRO
 *******************************************************************************/

/*******************************************************************************
 * Type Definition
 *******************************************************************************/

/*******************************************************************************
 * Prototypes of Local Functions
 *******************************************************************************/

/*******************************************************************************
 * Static Variable
 *******************************************************************************/

/*******************************************************************************
 * Exported Global Variables
 *******************************************************************************/
extern int count_Infrared;
/*******************************************************************************
 * Exported Functions
 * Function name: Infrared_Data_Process
 * Description:	Infrared_data using median filter
 *******************************************************************************/
void Infrared_Data_Process(void){			//Median Filter

	Infrared_input[count_Infrared] = VADC_G0_RES10.B.RESULT;
	Infrared_input_1[count_Infrared] = VADC_G0_RES1.B.RESULT;

	for(a = 0 ; a < 8 ; a++){

		for(b = a + 1 ; b < 9 ; b++){

			if(Infrared_input[a] > Infrared_input[b]){

				temp = Infrared_input[a];

				Infrared_input[a] = Infrared_input[b];

				Infrared_input[b] = temp;
			}
		}
	}

	for(a = 0 ; a < 8 ; a++){

		for(b = a + 1 ; b < 9 ; b++){

			if(Infrared_input_1[a] > Infrared_input_1[b]){

				temp_1 = Infrared_input_1[a];

				Infrared_input_1[a] = Infrared_input_1[b];

				Infrared_input_1[b] = temp_1;
			}
		}
	}

	if(count_Infrared == 8){

		Infrared_use = Infrared_input[5];
		Infrared_use_1 = Infrared_input_1[5];
	}

}
/*******************************************************************************
 * Local Functions
 * Function name:
 * Description:
 *******************************************************************************/
