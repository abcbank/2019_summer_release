/*******************************************************************************
* File name: ES_Types.c
* Author: Seokwon Kim
* Created date: 2016. 03. 25
* Objective: collection of type definition
* ----------------------------- Revision history -----------------------------
* version 0.1 - 2016. 03. 25
*   == Initial version of type definition (by Seokwon Kim)
*******************************************************************************/

#ifndef ES_TYPES_H_
#define ES_TYPES_H_


typedef unsigned char   bool;
typedef unsigned char   uint8;
typedef signed   char   sint8;
typedef unsigned short  uint16;
typedef signed   short  sint16;
typedef unsigned long   uint32;
typedef signed   long   sint32;
typedef float           float32;
typedef double          float64;

typedef volatile uint8  vuint8;
typedef volatile sint8  vsint8;
typedef volatile uint16 vuint16;
typedef volatile sint16 vsint16;
typedef volatile uint32 vuint32;
typedef volatile sint32 vsint32;


#define FALSE 0
#define TRUE 1


#endif /* ES_TYPES_H_ */
