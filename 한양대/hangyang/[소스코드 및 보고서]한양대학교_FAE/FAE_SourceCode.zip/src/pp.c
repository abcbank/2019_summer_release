/*
 * pp.c
 *
 *  Created on: 2017. 7. 12.
 *      Author:  FAE
 */


#include "Pure_Pursuit.h"
#include "math.h"
#include "stdio.h"
#include "PWM.h"
#include "Base_setting.h"


	volatile double x_point = 0.5;//ī�޶� �ٶ󺸴� ��
	volatile double y_point;//ī�޶� ������ ������ ��ġ
	volatile double ld;
	volatile double wheel_base = 0.277;//�ణ�Ÿ�
	volatile double steering_angle;
	volatile double steering_angle_test;
	volatile double pixelgain = 0.00509; //�ȼ��� ���� ���̿��� ����  ����/�ȼ�
	double steer_before_5;
	double steer_before_4;
	double steer_before_3;
	double steer_before_2;
	double steer_before_1;
	double steer_avg;


	extern int Left_line;
	extern int Right_line;
	extern long double Car_rpm;
	extern volatile double steering_angle;
	extern int Right_Value;
	extern int Left_Value;
	extern int schoolzone_speed;
	extern int line_status;


void PurePursuit()
{


	if(Left_line == Left_Value && Right_line == Right_Value ){

		if(schoolzone_speed == 1){
			if(steer_avg > 20){
				y_point = (33) * pixelgain;
			}
		}
		else if(steer_avg < -20){
			y_point = (-43) * pixelgain;
		}
	}

	else if (Left_line == Left_Value){

		y_point = (-Right_line + Right_Value) * pixelgain;//3
	}
	else if (Right_line == Right_Value){

		y_point = (-Left_line + Left_Value) * pixelgain;
	}
	else {

		if(line_status == 1){
			y_point = (-Right_line + Right_Value) * pixelgain;
		}
		else if(line_status == 0){
			y_point = (-Left_line + Left_Value) * pixelgain;
		}

	}



	ld = sqrt(pow(x_point,2) + pow(y_point,2));

	steering_angle_test= atan(2 * wheel_base * y_point / pow(ld,2)) * 180 / 3.14;


	if(schoolzone_speed == 0){
		steering_angle = steering_angle_test;

		if(steering_angle > 25)
		{
			steering_angle = 25;
		}
		else if(steering_angle < -25)
		{
			steering_angle = - 25;
		}
	}
	else{
	if(steering_angle > 8 || steering_angle < -8 ){
		steering_angle = steering_angle_test + steering_angle_test
	* pow((((658-Car_rpm)/60*3.14*0.083*0.05+0.347)/0.49),2); // rpm�� ���� steering_angle ���� ���� 95�϶� 518
	}else{
		steering_angle = steering_angle_test;
	}

	if(steering_angle > 18)
	{
		steering_angle = 26;
	}
	else if(steering_angle < -15)
	{
		steering_angle = - 26;
	}
	}


	steer_before_5 = steer_before_4;
	steer_before_4 = steer_before_3;
	steer_before_3 = steer_before_2;
	steer_before_2 = steer_before_1;
	steer_before_1 = steering_angle;

	steer_avg = (steer_before_1 + steer_before_2 + steer_before_3 + steer_before_4 + steer_before_5)/5 ;



	Servo_PWM_Duty(steering_angle);

}



