/*
 * cross_fcn.c
 *
 *  Created on: 2017. 7. 12.
 *      Author:  FAE
 */
#include "cross_fcn.h"
#include "PWM.h"
#include "Base_setting.h"

unsigned int del = 0;
unsigned int cr_count;


extern int Left_line;
extern int Right_line;





void R_to_L(void) {


	P13_OUT.U=0x0;
	P13_OUT.B.P0=1;

	cr_count = 0;

	while (1) {
		Servo_PWM_Duty(25);
		cr_count++;
		if (Left_line > 24 && cr_count > 70500)
			break;
		else if (cr_count > 100500)
			break;
	}




	cr_count = 0;
	P13_OUT.B.P2=1;



	while (1) {
		Servo_PWM_Duty(-25);
		cr_count++;
		if (Left_line < 15 && cr_count > 75000)
			break;
		else if (cr_count > 85000)
			break;


	}

	//

	P13_OUT.B.P0=0;
	P13_OUT.B.P1=0;
	P13_OUT.B.P2=0;


}


void L_to_R (void) {

	P13_OUT.U=0x0;
	P13_OUT.B.P3=1;

	cr_count = 0;

	while (1) {
		Servo_PWM_Duty(-25);
		cr_count++;
		if (Right_line < 105 && cr_count > 73000)
			break;
		else if (cr_count > 113000)
			break;


	}


	cr_count = 0;
	P13_OUT.B.P1=1;



	while (1) {
		Servo_PWM_Duty(25);
		cr_count++;
		if (Right_line > 105 && cr_count > 53000)
			break;
		else if (cr_count > 83000)
					break;


	}





	P13_OUT.B.P3=0;
	P13_OUT.B.P2=0;
	P13_OUT.B.P1=0;



}


