/*
 * AEB.c
 *
 *  Created on: 2017. 7. 12.
 *      Author:  FAE
 */


#include "AEB.h"
#include "AEB_PID.h"


extern int Hill_state;
extern volatile unsigned int inf_Val_Use_top;
extern volatile unsigned int inf_Val_Use_bot;


void AEB(void){

	if ((Hill_state == 4 || Hill_state == 0) && inf_Val_Use_top > 400 ){
		if(inf_Val_Use_bot > 550){

			AEB_PID(0);
		}
	}

}
