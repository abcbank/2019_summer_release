
/*
 * AEB_PID.c
 *
 *  Created on: 2017. 7. 12.
 *      Author:  FAE
 */


#include "AEB_PID.h"
#include "Base_setting.h"
#include "PWM.h"


long double error_before = 0;
long double integral = 0;
long double error;
long double derivative;
long double Motor_PID;
long double K_p = 0.0721;
long double K_i = 0.0124;
long double K_d = 0.0015;


extern long double Car_rpm;


void AEB_PID(long double reference_rpm){

	error = reference_rpm - Car_rpm;

	integral = integral + (error)*0.003;

	derivative = (error - error_before) / 0.003;



	Motor_PID = K_p * error + K_i * integral + K_d * derivative;

	error_before = error;


	if(Motor_PID >= 0){
		Motor_PWM_Duty(Motor_PID, 0);
	}

	else if(Motor_PID < 0){
		Motor_PWM_Duty(0, -Motor_PID);
	}

	if(Car_rpm < 30){
		Motor_PWM_Duty(0, 0);
	}


}




