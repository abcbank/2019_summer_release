/*
 * Camera_filter_line_det.c
 *
 *  Created on: 2017. 7. 12.
 *      Author:  FAE
 */


#include "Base_setting.h"
#include "Camera_filter_line_det.h"

int Camera_BYUN[128] = { 0, };
int Left_line_compare;
int Right_line_compare;
int Left_Value = 10;
int Right_Value = 120;
int Left_line;
int Right_line;
int Track_Center_line = 65;
int i = 0;
int j = 0;
int absorption_count;
int Line_threshold_Left  = 12100;
int Line_threshold_Right = 12100;
int turn_state = 0;
unsigned int k =0;
int  Left_line_before;
int Left_line_before1;
int Left_line_before2;
int Right_line_before;
int Right_line_before1;
int Right_line_before2;


extern int Camera_input[128];
extern volatile double y_point;
extern int schoolzone_speed;
extern int steering_angle;

void Camera_filter_line_det(void);

void Camera_filter_line_det(){

	int left_count = 0;
	int right_count = 0;
	/*Camera_filter*/
	for (i = 6; i < 122; i++)
		{
			Camera_BYUN[i]=Camera_input[i-6]+8*Camera_input[i-5]+26*Camera_input[i-4]
		+40*Camera_input[i-3]+15*Camera_input[i-2]-48*Camera_input[i-1]
		-84*Camera_input[i]-48*Camera_input[i+1]+15*Camera_input[i+2]+40*Camera_input[i+3]
		+26*Camera_input[i+4] +8*Camera_input[i+5]+Camera_input[i+6];
		}

	/*Line determine*/

   Left_line = Left_Value;
   Right_line = Right_Value;

   Left_line_before = Left_Value;
   Left_line_before1 = Left_Value;
   Left_line_before2 = Left_Value;
   Right_line_before = Right_Value;
   Right_line_before1 = Right_Value;
   Right_line_before2 = Right_Value;


   Right_line_compare = Camera_BYUN[Right_Value];
   Left_line_compare = Camera_BYUN[Track_Center_line];

   for (k = Left_Value; k < Track_Center_line; k++){

      if ( Camera_BYUN[k] >= Left_line_compare){
    	  Left_line_compare = Camera_BYUN[k];
    	  Left_line = k;
      }
   }

   for (k = Track_Center_line; k < Right_Value+1; k++){

         if ( Camera_BYUN[k] > Right_line_compare){
        	 Right_line_compare =  Camera_BYUN[k];
        	 Right_line = k;
         }
   }



   if (Left_line_compare < Line_threshold_Left){

   		Left_line = 10;
   	}
   	if (Right_line_compare < Line_threshold_Right){

   		Right_line = 120;
   	}

   	if(schoolzone_speed == 0){
   		if (Right_line < 100){//80
   			Left_line = Left_Value;
   			Track_Center_line = Left_Value+1;
   		}else if(Left_line > 30){//40
   			Right_line = Right_Value;
   			Track_Center_line = Right_Value-1;
   		}
   		else{
   			Track_Center_line = 65;  //60
   			}
   	}else{
   		if (Right_line < 100){//80
   		   			Left_line = Left_Value;
   		   			Track_Center_line = Left_Value+1;
   		   		}else if(Left_line > 30){//40
   		   			Right_line = Right_Value;
   		   			Track_Center_line = Right_Value-1;
   		   		}
   		   		else{
   		   			Track_Center_line = 65;
   		   			}


   		if ((y_point > 0.05)||(steering_angle>10) ) {
   			Track_Center_line = Left_Value+10;
   		}else if ( (y_point < -0.05)||(steering_angle<-10) ) {
   			Track_Center_line = Right_Value-10;
   		}else {
   			Track_Center_line=65;
   			}
   	}
   	Left_line_before2 = Left_line_before1;
   	Left_line_before1 = Left_line_before;
   	Left_line_before = Left_line;

   	Right_line_before2 = Right_line_before1;
   	Right_line_before1 = Right_line_before;
   	Right_line_before = Right_line;
}



