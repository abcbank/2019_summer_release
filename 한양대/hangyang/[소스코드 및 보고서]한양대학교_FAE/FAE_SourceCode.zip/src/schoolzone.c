/*
 * schoolzone.c
 *
 *  Created on: 2017. 7. 12.
 *      Author:  FAE
 */


#include "schoolzone.h"


unsigned int black_state = 0;
unsigned int school_count = 0;
unsigned int old_schoolzone_state = 0;
unsigned int Camera_Sig=0;
unsigned int black_count_test = 0;
int schoolzone_cross_open = 0;

extern unsigned int schoolzone_state;
extern int Camera_input[128];
extern int Camera_BYUN[128];
extern int schoolzone_speed;

void schoolzone()
{


	int i = 0;
	int j = 0;
	int black_count = 0;
	int Camera_Sum=0;




	//���� ���� ī�޶� ������ ������ �Ǵ��ϴ� ���
	for( j = 50;j < 80; j++){
		Camera_Sum = Camera_Sum + Camera_input[j];
	}
	Camera_Sig = Camera_Sum/30;

	for(i = 53 ; i < 73;i++){
		if(Camera_BYUN[i] > 12000){
		black_count++;
		}
	}
	black_count_test = black_count;


	if((Camera_Sig < 300)&&(black_count_test == 0))
	{
		black_state = 1;
	}
	else if((Camera_Sig > (300+150))){
		black_state = 0;
	}

	if(black_state == 1)
	{
		old_schoolzone_state = schoolzone_state;
	}
	else if (black_state == 0)
	{
		if(old_schoolzone_state == schoolzone_state)
		{
			if(schoolzone_state == 1){
				schoolzone_state = 0;
			}else if(schoolzone_state ==0){
				schoolzone_state = 1;
			}
		}
	}






	if(schoolzone_state == 0){
		schoolzone_cross_open = 1;
		schoolzone_speed = 1;
	}else if(schoolzone_state == 1){
		schoolzone_cross_open = 0;
		schoolzone_speed = 0;
	}
}
