/*
 * interrupt_handler.c
 *
 *  Created on: 2017. 7. 12.
 *      Author:  FAE
 */


#include "Base_setting.h"
#include "interrupts.h"
#include "PWM.h"
#include "Camera_filter_line_det.h"
#include "Pure_Pursuit.h"
#include "inf.h"
#include "line_cross.h"
#include "Timer.h"
#include "schoolzone.h"

typedef unsigned long  uint32;
int inf_count = 0;
volatile int Camera_input[128];
int trash = 0;
int Pixel_Data;
unsigned int c = 0;
volatile int count = 0;
volatile double normal_rpm_count = 0;
volatile double inverse_rpm_count = 0;
int pp_trans = 0;
int check_school_zone = 0;
int check_Hill_state = 0;
int check_dot_state = 0;


extern int Hill_state;
extern schoolzone_speed;
extern int dotdotdot;


void Interrupt_handler_setting(void);

void SI_Pin(int trash);

void CLK_pin(int trash);

void rpm_normal(int trash);

void rpm_inverse(int trash);

void Timer_itr(uint32 u32_Period);



void Interrupt_handler_setting(void) {
	/* Value for periodic event*/
	uint32 u32_Period = 12000;

	/*InterruptInitalize*/
	InterruptInit();

	/*Registration of interrupt handler )*/
	InterruptInstall(SRC_ID_GTMTOM07, SI_Pin, 1, 0);
	InterruptInstall(SRC_ID_GTMTOM06, CLK_pin, 2, 0);
	InterruptInstall(SRC_ID_GTMTIM02, rpm_normal, 3, 0);
	InterruptInstall(SRC_ID_GTMTIM03, rpm_inverse, 4, 0);
	InterruptInstall(SRC_ID_STM0SR0, Timer_itr, 5, u32_Period);


	/*System Timer Module Configuration */

	STM0_ISCR.B.CMP0IRR = 0x1;
	STM0_CMCON.B.MSIZE0 = 0b11111;
	STM0_CMCON.B.MSTART0 = 0b00000;
	STM0_CMP0.U = STM0_TIM0.B.STM31_0 + u32_Period;
	STM0_ICR.B.CMP0EN = 1;


}


void CLK_pin(int trash) {

	Pixel_Data = VADC_G0_RES3.B.RESULT;

	Camera_input[count] = Pixel_Data;

	count++;
	if( count%14 == 0){
		inf_count = (count/14)-1;
		if(inf_count < 9)
			inf();
		if(inf_count == 8){
			inf_count++;
		}
		else if(inf_count == 9){

		}
	}

	if(count == 127){
		obs_det();
	}
}


void SI_Pin(int trash) {
	check_school_zone++;
	check_Hill_state++;
	check_dot_state++;
	count = 0;
	Camera_filter_line_det();

	if(check_school_zone > 10 && ( Hill_state == 0 || Hill_state == 4)){
		schoolzone();
	}

	if (pp_trans == 0){
		PurePursuit();
		}
	if(schoolzone_speed == 1){
	if(dotdotdot == 0){
					dotline();
				}
	}

	if(check_school_zone == 12){
			check_school_zone = 11;
		}

	if(100 < check_Hill_state){
		check_Hill_state = 101;
	}
	if(100 < check_dot_state){
			check_dot_state = 101;
		}


}

void rpm_normal(int trash){
	normal_rpm_count = normal_rpm_count + 1;
}

void rpm_inverse(int trash){
	inverse_rpm_count = inverse_rpm_count + 1;

}

void Timer_itr(uint32 u32_Period){
	STM0_CMP0.U = STM0_CMP0.U + u32_Period;
	Timer();
}
