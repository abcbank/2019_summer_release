/*
 * RPM_calculation.c
 *
 *  Created on: 2017. 7. 12.
 *      Author:  FAE
 */


#include "RPM_calculation.h"


long double rpm_cal = 0;
long double Car_rpm = 0;
long double velocity = 0;
long double v[10000] = { 0,};
unsigned int v_count = 0;


extern volatile double normal_rpm_count;
extern volatile double inverse_rpm_count;


void rpm_cal_value(void){

	if(normal_rpm_count >= inverse_rpm_count){//positive direction
		rpm_cal = normal_rpm_count/3000/8*60*1000/3;
	}
	else if(normal_rpm_count < inverse_rpm_count){//negative direction
		rpm_cal = (-1) * inverse_rpm_count/3000/8*60*1000/3;
	}


	Car_rpm = rpm_cal;
	velocity = Car_rpm * 3.14 * 0.083 /60;

	v[v_count] = Car_rpm;
	v_count++;

	if(v_count == 9999){
		v_count = 0;
	}

	normal_rpm_count = 0;
	inverse_rpm_count = 0;
}
