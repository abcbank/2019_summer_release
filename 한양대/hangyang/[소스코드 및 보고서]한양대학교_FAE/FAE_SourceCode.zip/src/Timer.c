
#include "Timer.h"

typedef unsigned char   bool;
typedef unsigned short  uint16;

#define FALSE 0
#define TRUE 1



static uint16 u16_3ms_counter = 0;

static bool b_3ms_timer=FALSE;






void Timer(void)
{
	if(u16_3ms_counter % 30 == 0) b_3ms_timer = TRUE;
	u16_3ms_counter++;
	if (u16_3ms_counter>= 60000) u16_3ms_counter = 0;


}


bool Timer_3ms(void)
{
	if (b_3ms_timer)
	{
		b_3ms_timer = FALSE;

		return TRUE;
	}
	else
	{
		return FALSE;
	}




}

