/*
 * main.c
 *
 *  Created on: 2017. 7. 12.
 *      Author:  FAE
 */


#include <stdlib.h>
#include "Base_setting.h"
#include "interrupts.h"
#include "PLL.h"
#include "PWM.h"
#include "VADC.h"
#include "line_cross.h"
#include "RPM.h"
#include "schoolzone.h"
#include "RPM_calculation.h"
#include "Timer.h"
#include "AEB.h"
#include "cross_fcn.h"
#include "Pure_Pursuit.h"��
#include "Hill.h"


int obs = 0;
int line_status = 0;
int sec=0;
unsigned int schoolzone_state = 1;
int schoolzone_speed = 0;


extern int pp_trans;
extern int schoolzone_speed;
extern int inf_Val_Use_top;


//To strive, to seek, to find, and not to yield.
int main(void) {
	Interrupt_handler_setting();
	PLL_200();
	Camera_VADC_set();
	Setting_TOM();
	RPM_setting();
	Camera_PWM_Duty(125, 62, 16125, 125);//10ms
	P13_IOCR0.U = 0x80808080;

	if(inf_Val_Use_top < 10000){
		pp_trans = 0;
				}
	while(1) {

		Hill();

	if (schoolzone_speed == 0)
		{P13_OUT.U=0x0;
			if(inf_Val_Use_top < 600){
				obs = 0;
			}else{
				obs = 1;
			}
			if(obs == 0){
					Motor_PWM_Duty(77,0);
					if(Timer_3ms()){
						rpm_cal_value();
						if(sec == 0){
						sec=1;
						}else{
							sec=0;
						}
					}
			}else{
			if(Timer_3ms()){
				rpm_cal_value();
				AEB();
				if(sec == 0){
				sec=1;
				}else{
					sec=0;
				}
			}
			}
		}
		else if (schoolzone_speed == 1){
			P13_OUT.U=0xffff;



			if (pp_trans == 0){
				Motor_PWM_Duty(44,0);

			}

			else if (pp_trans == 1){
				Motor_PWM_Duty(42,0);
				line_cross();
			}

		}


	}


	return EXIT_SUCCESS;
}


