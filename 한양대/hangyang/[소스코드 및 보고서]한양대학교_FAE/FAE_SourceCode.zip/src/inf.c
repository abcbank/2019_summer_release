/*
 * inf.c
 *
 *  Created on: 2017. 7. 12.
 *      Author:  FAE
 */


#include "Base_setting.h"
#include "inf.h"



volatile unsigned int inf_Val[9] ={ 0, };
volatile unsigned int inf_Val_Use_top;
volatile unsigned int inf_Val_1[9] ={ 0, };
volatile unsigned int inf_Val_Use_bot;
int a = 0;
int b = 0;
int temp = 0;
int a_1 = 0;
int b_1 = 0;
int temp_1 = 0;


extern int inf_count;
extern int pp_trans;
extern int schoolzone_cross_open;
extern int Hill_state;




void inf(){


	inf_Val[inf_count] = VADC_G0_RES9.B.RESULT;
	inf_Val_1[inf_count] = VADC_G1_RES1.B.RESULT;

	for(a = 0 ; a < 8 ; a++){

		for(b = a + 1 ; b < 9 ; b++){

			if(inf_Val[a] > inf_Val[b]){

				temp = inf_Val[a];

				inf_Val[a] = inf_Val[b];

				inf_Val[b] = temp;
			}
		}
	}

	for(a_1 = 0 ; a_1 < 8 ; a_1++){

		for(b_1 = a_1 + 1 ; b_1 < 9 ; b_1++){

			if(inf_Val_1[a_1] > inf_Val_1[b_1]){

				temp_1 = inf_Val_1[a_1];

				inf_Val_1[a_1] = inf_Val_1[b_1];

				inf_Val_1[b_1] = temp_1;
			}
		}
	}

	if(inf_count == 8){
	inf_Val_Use_bot = inf_Val[5];
	inf_Val_Use_top = inf_Val_1[5];
	}




}


void obs_det(){

	if ((Hill_state == 0 || Hill_state == 4) && inf_Val_Use_top > 400 ){
	//if ((Hill_state == 0 || Hill_state == 4)){
		if(inf_Val_Use_top > 540){    //550
			if(schoolzone_cross_open == 1){   //���ι��� ��������϶��� ���� ���� �ʱ�ȭ�� 0�̹Ƿ� 1��  �س�����
				pp_trans = 1;
			}
			else{
				pp_trans = 0;
			}
		}
		else{
			pp_trans = 0;
		}
	}

}

