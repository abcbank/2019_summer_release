

#ifndef TIMER_H_
#define TIMER_H_





typedef unsigned char   bool;

void Timer(void);


bool Timer_3ms(void);




#endif /*TIMER_H_ */
