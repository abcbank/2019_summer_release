/*
 * cross_fcn.h
 *
 *  Created on: 2017. 6. 1.
 *      Author: baku
 */

#ifndef CROSS_FCN_H_
#define CROSS_FCN_H_

void R_to_L(void);
void L_to_R(void);

#endif /* CROSS_FCN_H_ */
