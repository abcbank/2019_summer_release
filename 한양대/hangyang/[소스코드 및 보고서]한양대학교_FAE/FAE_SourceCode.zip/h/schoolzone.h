/*
 * schoolzone.h
 *
 *  Created on: 2017. 6. 6.
 *      Author: baku
 */

#ifndef SCHOOLZONE_H_
#define SCHOOLZONE_H_

void schoolzone(void);

#endif /* SCHOOLZONE_H_ */
