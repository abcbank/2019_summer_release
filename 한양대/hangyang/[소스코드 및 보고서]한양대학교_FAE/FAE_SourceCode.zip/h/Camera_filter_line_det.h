

#ifndef CAMERA_FILTER_LINE_DET_H_
#define CAMERA_FILTER_LINE_DET_H_

void Camera_filter_line_det(void);

#endif /* CAMERA_FILTER_LINE_DET_H_ */
