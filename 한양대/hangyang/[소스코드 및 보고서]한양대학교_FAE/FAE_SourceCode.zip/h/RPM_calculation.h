/*
 * RPM_calculation.h
 *
 *  Created on: 2017. 5. 22.
 *      Author: baku
 */

#ifndef RPM_CALCULATION_H_
#define RPM_CALCULATION_H_

void rpm_cal_value(void);

#endif /* RPM_CALCULATION_H_ */
