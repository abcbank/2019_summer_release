/*
 * line_cross.h
 *
 *  Created on: 2017. 5. 30.
 *      Author: baku
 */

#ifndef LINE_CROSS_H_
#define LINE_CROSS_H_

void line_cross(void);
void dotline(void);

#endif /* LINE_CROSS_H_ */
