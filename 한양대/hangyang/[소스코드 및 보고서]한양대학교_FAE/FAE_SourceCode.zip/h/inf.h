/*
 * inf.h
 *
 *  Created on: 2017. 5. 30.
 *      Author: baku
 */

#ifndef INF_H_
#define INF_H_

void inf(void);
void obs_det(void);

#endif /* INF_H_ */
