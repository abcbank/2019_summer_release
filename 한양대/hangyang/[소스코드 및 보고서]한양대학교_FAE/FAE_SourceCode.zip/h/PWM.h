

#ifndef PWM_H_
#define PWM_H_





void Setting_TOM (void);
void Camera_PWM_Duty(int CLK0,int CLK1,int SI0,int SI1);
void Servo_PWM_Duty(long double servo_angle);
void Motor_PWM_Duty(unsigned int motor0, unsigned int motor1);
void Test_Servo(int servo0, long double servo_duty);

#endif
