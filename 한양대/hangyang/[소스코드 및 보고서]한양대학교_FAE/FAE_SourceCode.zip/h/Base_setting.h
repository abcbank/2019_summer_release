#include "tc23xa/IfxPort_reg.h"

#include "tc23xa/IfxStm_reg.h"

#include "tc23xa/IfxVadc_reg.h"

#include "tc23xa/IfxGtm_reg.h"

#include "tc23xa/IfxScu_reg.h"

#include <machine/wdtcon.h>
