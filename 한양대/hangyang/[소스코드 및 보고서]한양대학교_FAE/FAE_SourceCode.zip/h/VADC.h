


#ifndef VADC_H_
#define VADC_H_








void Camera_VADC_set(void);

#endif /*SYSTEMTIMER_H_ */
